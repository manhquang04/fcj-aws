﻿---
title: "Clean up Resources"
date: "2024-01-01"
weight: 6
chapter: false
pre: " <b> 5.6. </b> "
---

## Clean up Resources

{{% notice warning %}}
Complete this section to avoid unexpected charges. AWS resources incur costs while running.
{{% /notice %}}

### Resources Created in This Workshop

| Resource | Service | Created By |
| --- | --- | --- |
| Lambda Function | AWS Lambda | Terraform |
| API Gateway HTTP API | API Gateway | Terraform |
| DynamoDB Tables (3) | DynamoDB | Terraform |
| ECR Repository | ECR | Manual/Pipeline |
| CloudWatch Log Group | CloudWatch | Terraform |
| SNS Topic | SNS | Terraform |
| CloudWatch Alarms | CloudWatch | Terraform |
| IAM Role & Policies | IAM | Terraform |
| CodePipeline | CodePipeline | Terraform (optional) |
| CodeBuild Projects | CodeBuild | Terraform (optional) |

### Option 1: Terraform Destroy (Recommended)

If you used Terraform to create resources:

```bash
# Navigate to infra directory
cd infra

# Review what will be destroyed
terraform plan -destroy

# Destroy all resources
terraform destroy -auto-approve
```

![Terraform Destroy](/images/5-Workshop/5.6-Cleanup/terraform-destroy.png)

### Option 2: Manual Cleanup

#### Step 1: Delete Lambda Function

```bash
aws lambda delete-function --function-name fastapi-lambda-fn
```

#### Step 2: Delete API Gateway

```bash
# Get API ID
API_ID=$(aws apigatewayv2 get-apis --query "Items[?Name=='fastapi-lambda-http'].ApiId" --output text)

# Delete API
aws apigatewayv2 delete-api --api-id $API_ID
```

#### Step 3: Delete DynamoDB Tables

```bash
# Delete all three tables
aws dynamodb delete-table --table-name products
aws dynamodb delete-table --table-name orders
aws dynamodb delete-table --table-name users
```

#### Step 4: Delete ECR Repository

```bash
# Force delete with all images
aws ecr delete-repository --repository-name fastapi-lambda --force
```

#### Step 5: Delete CloudWatch Resources

```bash
# Delete log group
aws logs delete-log-group --log-group-name /aws/lambda/fastapi-lambda-fn

# Delete alarms
aws cloudwatch delete-alarms --alarm-names fastapi-lambda-5xx fastapi-lambda-high-latency fastapi-lambda-throttles
```

#### Step 6: Delete SNS Topic

```bash
# Get topic ARN
TOPIC_ARN=$(aws sns list-topics --query "Topics[?contains(TopicArn,'fastapi-lambda-alerts')].TopicArn" --output text)

# Delete topic
aws sns delete-topic --topic-arn $TOPIC_ARN
```

#### Step 7: Delete IAM Role

```bash
# Detach policies first
aws iam list-attached-role-policies --role-name fastapi-lambda-role --query "AttachedPolicies[].PolicyArn" --output text | xargs -n1 aws iam detach-role-policy --role-name fastapi-lambda-role --policy-arn

# Delete inline policies
aws iam list-role-policies --role-name fastapi-lambda-role --query "PolicyNames" --output text | xargs -n1 aws iam delete-role-policy --role-name fastapi-lambda-role --policy-name

# Delete role
aws iam delete-role --role-name fastapi-lambda-role
```

#### Step 8: Delete CodePipeline (if created)

```bash
aws codepipeline delete-pipeline --name fastapi-lambda-pipeline
```

#### Step 9: Delete CodeBuild Projects (if created)

```bash
aws codebuild delete-project --name fastapi-lambda-build
aws codebuild delete-project --name fastapi-lambda-deploy
```

### Verification

After cleanup, verify no resources remain:

```bash
# Check Lambda
aws lambda list-functions --query "Functions[?starts_with(FunctionName, 'fastapi-lambda')]"

# Check DynamoDB
aws dynamodb list-tables --query "TableNames[?contains(@, 'products') || contains(@, 'orders') || contains(@, 'users')]"

# Check ECR
aws ecr describe-repositories --query "repositories[?starts_with(repositoryName, 'fastapi-lambda')]"

# Check API Gateway
aws apigatewayv2 get-apis --query "Items[?starts_with(Name, 'fastapi-lambda')]"
```

### Cost Verification

1. Navigate to **AWS Cost Explorer**
2. Set date range to include workshop period
3. Verify no ongoing charges

### Summary

Congratulations! You have completed the FastAPI on AWS Lambda workshop.

**What you learned:**
- ✅ Build FastAPI applications with layered architecture
- ✅ Package Python apps as Lambda container images
- ✅ Set up CI/CD with CodePipeline and security scanning
- ✅ Deploy infrastructure with Terraform modules
- ✅ Implement JWT authentication
- ✅ Configure monitoring with CloudWatch and SNS

### Next Steps

- Add more API endpoints (PUT, DELETE for orders)
- Implement pagination for list endpoints
- Add caching with ElastiCache
- Set up custom domain with Route 53
- Implement rate limiting
- Add integration tests to the pipeline

#### Images Required:
- `terraform-destroy.png` - Terraform destroy output
- `resources-deleted.png` - Verification of deleted resources
