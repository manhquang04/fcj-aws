﻿---
title: "Dọn dẹp tài nguyên"
date: "2024-01-01"
weight: 6
chapter: false
pre: " <b> 5.6. </b> "
---

## Dọn dẹp tài nguyên

{{% notice warning %}}
Hoàn thành phần này để tránh các khoản phí không mong muốn. Tài nguyên AWS phát sinh chi phí khi đang chạy.
{{% /notice %}}

### Tài nguyên được tạo trong Workshop này

| Tài nguyên | Dịch vụ | Tạo bởi |
| --- | --- | --- |
| Lambda Function | AWS Lambda | Terraform |
| API Gateway HTTP API | API Gateway | Terraform |
| DynamoDB Tables (3) | DynamoDB | Terraform |
| ECR Repository | ECR | Manual/Pipeline |
| CloudWatch Log Group | CloudWatch | Terraform |
| SNS Topic | SNS | Terraform |
| CloudWatch Alarms | CloudWatch | Terraform |
| IAM Role & Policies | IAM | Terraform |
| CodePipeline | CodePipeline | Terraform (tùy chọn) |
| CodeBuild Projects | CodeBuild | Terraform (tùy chọn) |

### Cách 1: Terraform Destroy (Khuyến nghị)

Nếu bạn sử dụng Terraform để tạo tài nguyên:

```bash
# Điều hướng đến thư mục infra
cd infra

# Xem trước những gì sẽ bị xóa
terraform plan -destroy

# Xóa tất cả tài nguyên
terraform destroy -auto-approve
```

![Terraform Destroy](/images/5-Workshop/5.6-Cleanup/terraform-destroy.png)

### Cách 2: Cleanup thủ công

#### Bước 1: Xóa Lambda Function

```bash
aws lambda delete-function --function-name fastapi-lambda-fn
```

#### Bước 2: Xóa API Gateway

```bash
# Lấy API ID
API_ID=$(aws apigatewayv2 get-apis --query "Items[?Name=='fastapi-lambda-http'].ApiId" --output text)

# Xóa API
aws apigatewayv2 delete-api --api-id $API_ID
```

#### Bước 3: Xóa DynamoDB Tables

```bash
# Xóa cả ba tables
aws dynamodb delete-table --table-name products
aws dynamodb delete-table --table-name orders
aws dynamodb delete-table --table-name users
```

#### Bước 4: Xóa ECR Repository

```bash
# Force delete với tất cả images
aws ecr delete-repository --repository-name fastapi-lambda --force
```

#### Bước 5: Xóa CloudWatch Resources

```bash
# Xóa log group
aws logs delete-log-group --log-group-name /aws/lambda/fastapi-lambda-fn

# Xóa alarms
aws cloudwatch delete-alarms --alarm-names fastapi-lambda-5xx fastapi-lambda-high-latency fastapi-lambda-throttles
```

#### Bước 6: Xóa SNS Topic

```bash
# Lấy topic ARN
TOPIC_ARN=$(aws sns list-topics --query "Topics[?contains(TopicArn,'fastapi-lambda-alerts')].TopicArn" --output text)

# Xóa topic
aws sns delete-topic --topic-arn $TOPIC_ARN
```

#### Bước 7: Xóa IAM Role

```bash
# Gỡ policies trước
aws iam list-attached-role-policies --role-name fastapi-lambda-role --query "AttachedPolicies[].PolicyArn" --output text | xargs -n1 aws iam detach-role-policy --role-name fastapi-lambda-role --policy-arn

# Xóa inline policies
aws iam list-role-policies --role-name fastapi-lambda-role --query "PolicyNames" --output text | xargs -n1 aws iam delete-role-policy --role-name fastapi-lambda-role --policy-name

# Xóa role
aws iam delete-role --role-name fastapi-lambda-role
```

#### Bước 8: Xóa CodePipeline (nếu đã tạo)

```bash
aws codepipeline delete-pipeline --name fastapi-lambda-pipeline
```

#### Bước 9: Xóa CodeBuild Projects (nếu đã tạo)

```bash
aws codebuild delete-project --name fastapi-lambda-build
aws codebuild delete-project --name fastapi-lambda-deploy
```

### Xác minh

Sau khi cleanup, xác minh không còn tài nguyên:

```bash
# Kiểm tra Lambda
aws lambda list-functions --query "Functions[?starts_with(FunctionName, 'fastapi-lambda')]"

# Kiểm tra DynamoDB
aws dynamodb list-tables --query "TableNames[?contains(@, 'products') || contains(@, 'orders') || contains(@, 'users')]"

# Kiểm tra ECR
aws ecr describe-repositories --query "repositories[?starts_with(repositoryName, 'fastapi-lambda')]"

# Kiểm tra API Gateway
aws apigatewayv2 get-apis --query "Items[?starts_with(Name, 'fastapi-lambda')]"
```

### Xác minh Chi phí

1. Điều hướng đến **AWS Cost Explorer**
2. Đặt khoảng thời gian bao gồm period workshop
3. Xác minh không có chi phí đang phát sinh

### Tóm tắt

Chúc mừng! Bạn đã hoàn thành workshop FastAPI trên AWS Lambda.

**Những gì bạn đã học:**
- ✅ Xây dựng ứng dụng FastAPI với kiến trúc phân lớp
- ✅ Đóng gói Python apps thành Lambda container images
- ✅ Thiết lập CI/CD với CodePipeline và security scanning
- ✅ Deploy infrastructure với Terraform modules
- ✅ Triển khai JWT authentication
- ✅ Cấu hình monitoring với CloudWatch và SNS

### Bước tiếp theo

- Thêm API endpoints (PUT, DELETE cho orders)
- Triển khai pagination cho list endpoints
- Thêm caching với ElastiCache
- Thiết lập custom domain với Route 53
- Triển khai rate limiting
- Thêm integration tests vào pipeline

#### Ảnh cần thiết:
- `terraform-destroy.png` - Output terraform destroy
- `resources-deleted.png` - Xác minh tài nguyên đã xóa
