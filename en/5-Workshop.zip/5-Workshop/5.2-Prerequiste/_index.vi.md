﻿---
title: "Chuẩn bị"
date: "2024-01-01"
weight: 2
chapter: false
pre: " <b> 5.2. </b> "
---

## Yêu cầu chuẩn bị

Trước khi bắt đầu workshop này, hãy đảm bảo bạn đã chuẩn bị đầy đủ các yêu cầu sau.

### 1. Tài khoản AWS

Bạn cần một tài khoản AWS với quyền phù hợp. Nếu chưa có:

1. Truy cập [AWS Console](https://aws.amazon.com/)
2. Click **Create an AWS Account**
3. Làm theo quy trình đăng ký
4. Bật MFA cho tài khoản root (khuyến nghị)

![AWS Account Creation](/images/5-Workshop/5.2-Prerequiste/aws-account.png)

{{% notice warning %}}
Workshop này sẽ tạo các tài nguyên phát sinh chi phí. Chi phí ước tính ~$5-10 nếu dọn dẹp trong vài giờ. Hãy đảm bảo hoàn thành phần dọn dẹp cuối cùng.
{{% /notice %}}

### 2. IAM User với quyền cần thiết

Tạo một IAM user với các managed policies sau:
- `AdministratorAccess` (chỉ dành cho mục đích workshop)

Hoặc tạo custom policy với quyền cho:
- Lambda, API Gateway, DynamoDB
- CodePipeline, CodeBuild, CodeDeploy
- CloudFront, Route 53, WAF
- Cognito, Secrets Manager, KMS
- CloudWatch, CloudTrail, GuardDuty, EventBridge, SNS
- IAM, ECR, S3

### 3. Tài khoản GitLab

1. Đăng ký tại [GitLab](https://gitlab.com/)
2. Tạo project/repository mới
3. Tạo Personal Access Token với scopes `api` và `write_repository`

![GitLab Setup](/images/5-Workshop/5.2-Prerequiste/gitlab-setup.png)

### 4. Môi trường phát triển cục bộ

Cài đặt các công cụ sau trên máy tính của bạn:

| Công cụ | Phiên bản | Mục đích |
| --- | --- | --- |
| **AWS CLI** | v2.x | Tương tác với các dịch vụ AWS |
| **Terraform** | v1.5+ | Infrastructure as Code |
| **Git** | Mới nhất | Quản lý phiên bản |
| **Docker** | Mới nhất | Build container |
| **Node.js** | v18+ | Phát triển Lambda function |
| **Python** | v3.9+ | Phát triển Lambda function |

#### Cài đặt AWS CLI

```bash
# Windows (PowerShell)
msiexec.exe /i https://awscli.amazonaws.com/AWSCLIV2.msi

# macOS
brew install awscli

# Linux
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
```

#### Cấu hình AWS CLI

```bash
aws configure
# Nhập Access Key ID
# Nhập Secret Access Key
# Nhập default region: ap-southeast-1
# Nhập output format: json
```

#### Cài đặt Terraform

```bash
# Windows (Chocolatey)
choco install terraform

# macOS
brew tap hashicorp/tap
brew install hashicorp/tap/terraform

# Linux
sudo apt-get update && sudo apt-get install -y gnupg software-properties-common
wget -O- https://apt.releases.hashicorp.com/gpg | gpg --dearmor | sudo tee /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install terraform
```

### 5. Tên miền (Tùy chọn)

Để cấu hình Route 53 và CloudFront, bạn có thể tùy chọn sử dụng:
- Tên miền đã đăng ký, HOẶC
- Sử dụng domain mặc định của CloudFront để test

### 6. Xác minh cài đặt

Chạy các lệnh sau để xác minh cài đặt:

```bash
# Kiểm tra AWS CLI
aws --version
aws sts get-caller-identity

# Kiểm tra Terraform
terraform --version

# Kiểm tra Git
git --version

# Kiểm tra Docker
docker --version

# Kiểm tra Node.js
node --version
npm --version
```

![Verify Setup](/images/5-Workshop/5.2-Prerequiste/verify-setup.png)

### 7. Clone Workshop Repository

```bash
git clone https://gitlab.com/your-username/secure-serverless-workshop.git
cd secure-serverless-workshop
```

### Tải tài nguyên Workshop

Tải starter code và Terraform modules:

{{% notice info %}}
Repository workshop bao gồm:
- Terraform modules cho tất cả tài nguyên AWS
- Code Lambda function mẫu
- File cấu hình GitLab CI/CD
- Cấu hình quét bảo mật
{{% /notice %}}

#### Ảnh cần thiết cho phần này:
- `aws-account.png` - Màn hình tạo/đăng nhập tài khoản AWS
- `gitlab-setup.png` - Tạo project và token GitLab
- `verify-setup.png` - Terminal hiển thị kiểm tra phiên bản thành công
- `iam-permissions.png` - Cấu hình quyền IAM user
