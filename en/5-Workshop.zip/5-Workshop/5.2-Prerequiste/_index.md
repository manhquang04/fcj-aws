﻿---
title: "Prerequisites"
date: "2024-01-01"
weight: 2
chapter: false
pre: " <b> 5.2. </b> "
---

## Prerequisites

Before starting this workshop, ensure you have the following requirements ready.

### 1. AWS Account

You need an AWS account with appropriate permissions. If you don't have one:

1. Go to [AWS Console](https://aws.amazon.com/)
2. Click **Create an AWS Account**
3. Follow the registration process
4. Enable MFA for the root account (recommended)

![AWS Account Creation](/images/5-Workshop/5.2-Prerequiste/aws-account.png)

{{% notice warning %}}
This workshop will create resources that incur costs. Estimated cost is ~$5-10 if cleaned up within a few hours. Make sure to complete the cleanup section at the end.
{{% /notice %}}

### 2. IAM User with Required Permissions

Create an IAM user with the following managed policies:
- `AdministratorAccess` (for workshop purposes only)

Or create a custom policy with permissions for:
- Lambda, API Gateway, DynamoDB
- CodePipeline, CodeBuild, CodeDeploy
- CloudFront, Route 53, WAF
- Cognito, Secrets Manager, KMS
- CloudWatch, CloudTrail, GuardDuty, EventBridge, SNS
- IAM, ECR, S3

### 3. GitLab Account

1. Sign up at [GitLab](https://gitlab.com/)
2. Create a new project/repository
3. Generate a Personal Access Token with `api` and `write_repository` scopes

![GitLab Setup](/images/5-Workshop/5.2-Prerequiste/gitlab-setup.png)

### 4. Local Development Environment

Install the following tools on your local machine:

| Tool | Version | Purpose |
| --- | --- | --- |
| **AWS CLI** | v2.x | Interact with AWS services |
| **Terraform** | v1.5+ | Infrastructure as Code |
| **Git** | Latest | Version control |
| **Docker** | Latest | Container building |
| **Node.js** | v18+ | Lambda function development |
| **Python** | v3.9+ | Lambda function development |

#### Install AWS CLI

```bash
# Windows (PowerShell)
msiexec.exe /i https://awscli.amazonaws.com/AWSCLIV2.msi

# macOS
brew install awscli

# Linux
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
```

#### Configure AWS CLI

```bash
aws configure
# Enter your Access Key ID
# Enter your Secret Access Key
# Enter default region: ap-southeast-1
# Enter output format: json
```

#### Install Terraform

```bash
# Windows (Chocolatey)
choco install terraform

# macOS
brew tap hashicorp/tap
brew install hashicorp/tap/terraform

# Linux
sudo apt-get update && sudo apt-get install -y gnupg software-properties-common
wget -O- https://apt.releases.hashicorp.com/gpg | gpg --dearmor | sudo tee /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install terraform
```

### 5. Domain Name (Optional)

For Route 53 and CloudFront configuration, you can optionally use:
- A registered domain name, OR
- Use CloudFront's default domain for testing

### 6. Verify Setup

Run the following commands to verify your setup:

```bash
# Check AWS CLI
aws --version
aws sts get-caller-identity

# Check Terraform
terraform --version

# Check Git
git --version

# Check Docker
docker --version

# Check Node.js
node --version
npm --version
```

![Verify Setup](/images/5-Workshop/5.2-Prerequiste/verify-setup.png)

### 7. Clone Workshop Repository

```bash
git clone https://gitlab.com/your-username/secure-serverless-workshop.git
cd secure-serverless-workshop
```

### Workshop Resources Download

Download the starter code and Terraform modules:

{{% notice info %}}
The workshop repository contains:
- Terraform modules for all AWS resources
- Sample Lambda function code
- GitLab CI/CD configuration files
- Security scanning configuration
{{% /notice %}}

#### Images Required for this section:
- `aws-account.png` - AWS account creation/login screen
- `gitlab-setup.png` - GitLab project and token creation
- `verify-setup.png` - Terminal showing successful version checks
- `iam-permissions.png` - IAM user permissions configuration
