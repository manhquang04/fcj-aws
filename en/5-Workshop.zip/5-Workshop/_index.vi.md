﻿---
title: "Workshop"
date: "2024-01-01"
weight: 5
chapter: false
pre: " <b> 5. </b> "
---

# Xây dựng FastAPI Backend trên AWS Lambda với DevSecOps

#### Tổng quan

Workshop này hướng dẫn bạn xây dựng một **FastAPI Backend API** hoàn chỉnh chạy trên **AWS Lambda** (container-based) với pipeline CI/CD tự động, tích hợp quét bảo mật, và Infrastructure as Code sử dụng Terraform.

Bạn sẽ học cách:
- Xây dựng ứng dụng **FastAPI** với kiến trúc phân lớp (API → Service → Repository)
- Đóng gói FastAPI thành **Lambda container image** sử dụng Mangum adapter
- Thiết lập CI/CD pipeline với **GitLab CI** và **AWS CodePipeline/CodeBuild**
- Tích hợp quét bảo mật với **Semgrep** (SAST) và **Trivy** (vulnerability scanning)
- Triển khai infrastructure sử dụng **Terraform** modules
- Lưu trữ dữ liệu trong các bảng **DynamoDB** (products, orders, users)
- Triển khai **JWT authentication** với Secrets Manager
- Thiết lập monitoring với **CloudWatch** và cảnh báo **SNS**

#### Kiến trúc

![System Architecture](/images/5-Workshop/workshop-architecture.png)

Kiến trúc tuân theo luồng request sau:

```
Client Request
    ↓
API Gateway (HTTP API)
    ↓
Lambda Function (Container)
    ↓
Mangum (ASGI Adapter)
    ↓
FastAPI Application
    ├── /auth    → Authentication (JWT)
    ├── /products → Product CRUD
    └── /orders   → Order CRUD
    ↓
DynamoDB Tables
    ├── products (product_id, name, price, stock, category)
    ├── orders   (order_id, user_id, products, status)
    └── users    (user_id, email, password_hash)
```

#### Cấu trúc dự án

```
devsecops-aws/
├── backend/                 # Ứng dụng FastAPI
│   ├── app/
│   │   ├── api/routers/     # API endpoints (auth, products, orders)
│   │   ├── services/        # Business logic layer
│   │   ├── repositories/    # DynamoDB data access
│   │   ├── models/          # Pydantic models
│   │   ├── core/            # Config, security, logging
│   │   ├── main.py          # FastAPI app entry point
│   │   └── lambda_handler.py # Lambda handler (Mangum)
│   ├── Dockerfile           # Lambda container image
│   ├── requirements.txt
│   ├── semgrep.yml          # Security scanning rules
│   └── trivyignore.txt
├── infra/                   # Terraform Infrastructure
│   ├── main.tf              # Điều phối chính
│   ├── variables.tf
│   ├── modules/
│   │   ├── dynamodb/        # DynamoDB tables
│   │   ├── iam/             # IAM roles & policies
│   │   ├── lambda_container/ # Lambda function
│   │   ├── apigw/           # API Gateway HTTP API
│   │   ├── observability/   # CloudWatch & SNS
│   │   └── route53/         # Custom domain (tùy chọn)
├── pipeline/                # AWS CodePipeline config
│   ├── buildspec-build.yml
│   ├── buildspec-deploy.yml
│   └── codepipeline.tf
└── .gitlab-ci.yml           # GitLab CI/CD
```

#### Nội dung

1. [Tổng quan Workshop](5.1-Workshop-overview/)
2. [Chuẩn bị](5.2-Prerequiste/)
3. [Thiết lập Pipeline CI/CD](5.3-S3-vpc/)
4. [Xây dựng FastAPI Backend](5.4-S3-onprem/)
5. [Monitoring & Observability](5.5-Policy/)
6. [Dọn dẹp tài nguyên](5.6-Cleanup/)

#### Các dịch vụ AWS được sử dụng

| Danh mục | Dịch vụ |
| --- | --- |
| **Compute** | AWS Lambda (Container Image) |
| **API** | API Gateway HTTP API (v2) |
| **Database** | Amazon DynamoDB |
| **Bảo mật** | AWS Secrets Manager, IAM |
| **CI/CD** | AWS CodePipeline, CodeBuild, ECR |
| **Monitoring** | Amazon CloudWatch, SNS |
| **DNS** | Amazon Route 53 (tùy chọn) |
| **IaC** | Terraform |

#### Thời gian & Chi phí ước tính

| Mục | Chi tiết |
| --- | --- |
| **Thời gian** | 3-4 giờ |
| **Cấp độ** | Trung cấp |
| **Chi phí** | ~$5-10 (nếu dọn dẹp sau workshop) |
