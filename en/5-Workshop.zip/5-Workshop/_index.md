﻿---
title: "Workshop"
date: "2024-01-01"
weight: 5
chapter: false
pre: " <b> 5. </b> "
---

# Building a FastAPI Backend on AWS Lambda with DevSecOps

#### Overview

This workshop guides you through building a complete **FastAPI Backend API** running on **AWS Lambda** (container-based) with automated CI/CD pipeline, integrated security scanning, and Infrastructure as Code using Terraform.

You will learn how to:
- Build a **FastAPI** application with layered architecture (API → Service → Repository)
- Package FastAPI as a **Lambda container image** using Mangum adapter
- Set up CI/CD pipeline with **GitLab CI** and **AWS CodePipeline/CodeBuild**
- Integrate security scanning with **Semgrep** (SAST) and **Trivy** (vulnerability scanning)
- Deploy infrastructure using **Terraform** modules
- Store data in **DynamoDB** tables (products, orders, users)
- Implement **JWT authentication** with Secrets Manager
- Set up monitoring with **CloudWatch** and **SNS** alerts

#### Architecture

![System Architecture](/images/5-Workshop/workshop-architecture.png)

The architecture follows this request flow:

```
Client Request
    ↓
API Gateway (HTTP API)
    ↓
Lambda Function (Container)
    ↓
Mangum (ASGI Adapter)
    ↓
FastAPI Application
    ├── /auth    → Authentication (JWT)
    ├── /products → Product CRUD
    └── /orders   → Order CRUD
    ↓
DynamoDB Tables
    ├── products (product_id, name, price, stock, category)
    ├── orders   (order_id, user_id, products, status)
    └── users    (user_id, email, password_hash)
```

#### Project Structure

```
devsecops-aws/
├── backend/                 # FastAPI Application
│   ├── app/
│   │   ├── api/routers/     # API endpoints (auth, products, orders)
│   │   ├── services/        # Business logic layer
│   │   ├── repositories/    # DynamoDB data access
│   │   ├── models/          # Pydantic models
│   │   ├── core/            # Config, security, logging
│   │   ├── main.py          # FastAPI app entry point
│   │   └── lambda_handler.py # Lambda handler (Mangum)
│   ├── Dockerfile           # Lambda container image
│   ├── requirements.txt
│   ├── semgrep.yml          # Security scanning rules
│   └── trivyignore.txt
├── infra/                   # Terraform Infrastructure
│   ├── main.tf              # Main orchestration
│   ├── variables.tf
│   ├── modules/
│   │   ├── dynamodb/        # DynamoDB tables
│   │   ├── iam/             # IAM roles & policies
│   │   ├── lambda_container/ # Lambda function
│   │   ├── apigw/           # API Gateway HTTP API
│   │   ├── observability/   # CloudWatch & SNS
│   │   └── route53/         # Custom domain (optional)
├── pipeline/                # AWS CodePipeline config
│   ├── buildspec-build.yml
│   ├── buildspec-deploy.yml
│   └── codepipeline.tf
└── .gitlab-ci.yml           # GitLab CI/CD
```

#### Content

1. [Workshop Overview](5.1-Workshop-overview/)
2. [Prerequisites](5.2-Prerequiste/)
3. [Setting up CI/CD Pipeline](5.3-S3-vpc/)
4. [Building FastAPI Backend](5.4-S3-onprem/)
5. [Monitoring & Observability](5.5-Policy/)
6. [Clean up Resources](5.6-Cleanup/)

#### AWS Services Used

| Category | Services |
| --- | --- |
| **Compute** | AWS Lambda (Container Image) |
| **API** | API Gateway HTTP API (v2) |
| **Database** | Amazon DynamoDB |
| **Security** | AWS Secrets Manager, IAM |
| **CI/CD** | AWS CodePipeline, CodeBuild, ECR |
| **Monitoring** | Amazon CloudWatch, SNS |
| **DNS** | Amazon Route 53 (optional) |
| **IaC** | Terraform |

#### Estimated Time & Cost

| Item | Details |
| --- | --- |
| **Duration** | 3-4 hours |
| **Level** | Intermediate |
| **Cost** | ~$5-10 (if cleaned up after workshop) |
