﻿---
title: "Monitoring & Observability"
date: "2024-01-01"
weight: 5
chapter: false
pre: " <b> 5.5. </b> "
---

## Monitoring & Observability

Trong phần này, bạn sẽ thiết lập monitoring và alerting cho ứng dụng FastAPI Lambda sử dụng CloudWatch và SNS.

![Monitoring Architecture](/images/5-Workshop/5.5-Monitoring/monitoring-architecture.png)

### Các thành phần Observability

| Thành phần | Dịch vụ AWS | Mục đích |
| --- | --- | --- |
| **Logs** | CloudWatch Logs | Lưu trữ và truy vấn application logs |
| **Metrics** | CloudWatch Metrics | Lambda invocations, errors, duration |
| **Alarms** | CloudWatch Alarms | Cảnh báo khi vượt ngưỡng error |
| **Notifications** | SNS | Gửi alerts qua email/SMS |

### Terraform Observability Module

Đây là module observability thực tế từ dự án:

```hcl
# infra/modules/observability/main.tf
variable "project_name" {}
variable "lambda_name" {}

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${var.lambda_name}"
  retention_in_days = 14
}

resource "aws_sns_topic" "alerts" {
  name = "${var.project_name}-alerts"
}

resource "aws_cloudwatch_metric_alarm" "lambda_errors" {
  alarm_name          = "${var.project_name}-5xx"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "Sum"
  threshold           = 1
  dimensions          = { FunctionName = var.lambda_name }
  alarm_actions       = [aws_sns_topic.alerts.arn]
}

output "alerts_topic_arn" { value = aws_sns_topic.alerts.arn }
```

### Sử dụng Module trong main.tf

```hcl
# infra/main.tf
module "observability" {
  source       = "./modules/observability"
  project_name = var.project_name
  lambda_name  = module.lambda.lambda_name
}
```

### Cấu hình CloudWatch Log Group

Log group được tự động tạo cho Lambda với:
- **Retention**: 14 ngày (có thể cấu hình)
- **Log stream**: Tạo cho mỗi Lambda execution environment

### Lambda Error Alarm

Alarm trigger khi:
- **Metric**: Lambda Errors
- **Threshold**: > 1 error
- **Period**: 60 giây (1 phút)
- **Evaluation**: 1 period

### SNS Alert Topic

Cấu hình email subscription cho alerts:

```bash
# Subscribe email vào SNS topic
aws sns subscribe \
    --topic-arn arn:aws:sns:us-east-1:ACCOUNT_ID:fastapi-lambda-alerts \
    --protocol email \
    --notification-endpoint your-email@example.com
```

### Cấu hình Application Logging

Ứng dụng sử dụng structured logging cho CloudWatch:

```python
# backend/app/core/logging.py
import logging
import json
import sys

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_obj = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
        }
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_obj)

def configure_logging():
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers = [handler]
```

### Correlation ID Middleware

Theo dõi requests qua logs với correlation IDs:

```python
# backend/app/api/middleware.py
import uuid
import logging
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

logger = logging.getLogger(__name__)

class CorrelationMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
        
        logger.info(f"Request started", extra={
            "correlation_id": correlation_id,
            "method": request.method,
            "path": request.url.path
        })
        
        response = await call_next(request)
        response.headers["X-Correlation-ID"] = correlation_id
        
        logger.info(f"Request completed", extra={
            "correlation_id": correlation_id,
            "status_code": response.status_code
        })
        
        return response

def add_correlation_middleware(app):
    app.add_middleware(CorrelationMiddleware)
```

### CloudWatch Insights Queries

Các queries hữu ích để phân tích logs:

```sql
-- Tìm tất cả errors trong 24 giờ qua
fields @timestamp, @message
| filter @message like /ERROR/
| sort @timestamp desc
| limit 100

-- Phân tích latency request
fields @timestamp, @duration
| stats avg(@duration) as avg_duration, 
        max(@duration) as max_duration,
        count() as request_count
| by bin(1h)

-- Top error messages
fields @message
| filter level = "ERROR"
| stats count() by message
| sort count desc
| limit 10
```

### Tạo thêm Alarms

Thêm alarms cho observability tốt hơn:

```hcl
# High latency alarm
resource "aws_cloudwatch_metric_alarm" "lambda_duration" {
  alarm_name          = "${var.project_name}-high-latency"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "Duration"
  namespace           = "AWS/Lambda"
  period              = 300
  statistic           = "Average"
  threshold           = 5000  # 5 giây
  dimensions          = { FunctionName = var.lambda_name }
  alarm_actions       = [aws_sns_topic.alerts.arn]
}

# Throttling alarm
resource "aws_cloudwatch_metric_alarm" "lambda_throttles" {
  alarm_name          = "${var.project_name}-throttles"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Throttles"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "Sum"
  threshold           = 1
  dimensions          = { FunctionName = var.lambda_name }
  alarm_actions       = [aws_sns_topic.alerts.arn]
}
```

### Xem Logs trong AWS Console

1. Điều hướng đến **CloudWatch** → **Log groups**
2. Chọn `/aws/lambda/fastapi-lambda-fn`
3. Duyệt log streams cho các invocations cụ thể

![CloudWatch Logs](/images/5-Workshop/5.5-Monitoring/cloudwatch-logs.png)

### Xem Metrics

1. Điều hướng đến **CloudWatch** → **Metrics**
2. Chọn **Lambda** → **By Function Name**
3. Chọn function của bạn và chọn metrics:
   - Invocations
   - Errors
   - Duration
   - ConcurrentExecutions

![CloudWatch Metrics](/images/5-Workshop/5.5-Monitoring/cloudwatch-metrics.png)

{{% notice tip %}}
Sử dụng CloudWatch Logs Insights cho phân tích log nâng cao. Logs định dạng JSON giúp dễ dàng filter và aggregate dữ liệu.
{{% /notice %}}

#### Ảnh cần thiết:
- `monitoring-architecture.png` - Sơ đồ luồng monitoring
- `cloudwatch-logs.png` - Giao diện CloudWatch log group
- `cloudwatch-metrics.png` - Lambda metrics dashboard
- `sns-subscription.png` - SNS email subscription
- `alarm-triggered.png` - Alarm ở trạng thái ALARM
