﻿---
title: "Monitoring & Observability"
date: "2024-01-01"
weight: 5
chapter: false
pre: " <b> 5.5. </b> "
---

## Monitoring & Observability

In this section, you will set up monitoring and alerting for your FastAPI Lambda application using CloudWatch and SNS.

![Monitoring Architecture](/images/5-Workshop/5.5-Monitoring/monitoring-architecture.png)

### Observability Components

| Component | AWS Service | Purpose |
| --- | --- | --- |
| **Logs** | CloudWatch Logs | Store and query application logs |
| **Metrics** | CloudWatch Metrics | Lambda invocations, errors, duration |
| **Alarms** | CloudWatch Alarms | Alert on error thresholds |
| **Notifications** | SNS | Send alerts via email/SMS |

### Terraform Observability Module

This is the actual observability module from the project:

```hcl
# infra/modules/observability/main.tf
variable "project_name" {}
variable "lambda_name" {}

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${var.lambda_name}"
  retention_in_days = 14
}

resource "aws_sns_topic" "alerts" {
  name = "${var.project_name}-alerts"
}

resource "aws_cloudwatch_metric_alarm" "lambda_errors" {
  alarm_name          = "${var.project_name}-5xx"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "Sum"
  threshold           = 1
  dimensions          = { FunctionName = var.lambda_name }
  alarm_actions       = [aws_sns_topic.alerts.arn]
}

output "alerts_topic_arn" { value = aws_sns_topic.alerts.arn }
```

### Module Usage in main.tf

```hcl
# infra/main.tf
module "observability" {
  source       = "./modules/observability"
  project_name = var.project_name
  lambda_name  = module.lambda.lambda_name
}
```

### CloudWatch Log Group Configuration

The log group is automatically created for Lambda with:
- **Retention**: 14 days (configurable)
- **Log stream**: Created per Lambda execution environment

### Lambda Error Alarm

The alarm triggers when:
- **Metric**: Lambda Errors
- **Threshold**: > 1 error
- **Period**: 60 seconds (1 minute)
- **Evaluation**: 1 period

### SNS Alert Topic

Configure email subscription for alerts:

```bash
# Subscribe email to SNS topic
aws sns subscribe \
    --topic-arn arn:aws:sns:us-east-1:ACCOUNT_ID:fastapi-lambda-alerts \
    --protocol email \
    --notification-endpoint your-email@example.com
```

### Application Logging Configuration

The application uses structured logging for CloudWatch:

```python
# backend/app/core/logging.py
import logging
import json
import sys

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_obj = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
        }
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_obj)

def configure_logging():
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers = [handler]
```

### Correlation ID Middleware

Track requests across logs with correlation IDs:

```python
# backend/app/api/middleware.py
import uuid
import logging
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

logger = logging.getLogger(__name__)

class CorrelationMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
        
        logger.info(f"Request started", extra={
            "correlation_id": correlation_id,
            "method": request.method,
            "path": request.url.path
        })
        
        response = await call_next(request)
        response.headers["X-Correlation-ID"] = correlation_id
        
        logger.info(f"Request completed", extra={
            "correlation_id": correlation_id,
            "status_code": response.status_code
        })
        
        return response

def add_correlation_middleware(app):
    app.add_middleware(CorrelationMiddleware)
```

### CloudWatch Insights Queries

Useful queries for analyzing logs:

```sql
-- Find all errors in last 24 hours
fields @timestamp, @message
| filter @message like /ERROR/
| sort @timestamp desc
| limit 100

-- Request latency analysis
fields @timestamp, @duration
| stats avg(@duration) as avg_duration, 
        max(@duration) as max_duration,
        count() as request_count
| by bin(1h)

-- Top error messages
fields @message
| filter level = "ERROR"
| stats count() by message
| sort count desc
| limit 10
```

### Creating Additional Alarms

Add more alarms for better observability:

```hcl
# High latency alarm
resource "aws_cloudwatch_metric_alarm" "lambda_duration" {
  alarm_name          = "${var.project_name}-high-latency"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "Duration"
  namespace           = "AWS/Lambda"
  period              = 300
  statistic           = "Average"
  threshold           = 5000  # 5 seconds
  dimensions          = { FunctionName = var.lambda_name }
  alarm_actions       = [aws_sns_topic.alerts.arn]
}

# Throttling alarm
resource "aws_cloudwatch_metric_alarm" "lambda_throttles" {
  alarm_name          = "${var.project_name}-throttles"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Throttles"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "Sum"
  threshold           = 1
  dimensions          = { FunctionName = var.lambda_name }
  alarm_actions       = [aws_sns_topic.alerts.arn]
}
```

### Viewing Logs in AWS Console

1. Navigate to **CloudWatch** → **Log groups**
2. Select `/aws/lambda/fastapi-lambda-fn`
3. Browse log streams for specific invocations

![CloudWatch Logs](/images/5-Workshop/5.5-Monitoring/cloudwatch-logs.png)

### Viewing Metrics

1. Navigate to **CloudWatch** → **Metrics**
2. Select **Lambda** → **By Function Name**
3. Choose your function and select metrics:
   - Invocations
   - Errors
   - Duration
   - ConcurrentExecutions

![CloudWatch Metrics](/images/5-Workshop/5.5-Monitoring/cloudwatch-metrics.png)

{{% notice tip %}}
Use CloudWatch Logs Insights for advanced log analysis. The JSON-formatted logs make it easy to filter and aggregate data.
{{% /notice %}}

#### Images Required:
- `monitoring-architecture.png` - Monitoring flow diagram
- `cloudwatch-logs.png` - CloudWatch log group view
- `cloudwatch-metrics.png` - Lambda metrics dashboard
- `sns-subscription.png` - SNS email subscription
- `alarm-triggered.png` - Alarm in ALARM state
