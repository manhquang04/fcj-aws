﻿---
title: "Tổng quan Workshop"
date: "2024-01-01"
weight: 1
chapter: false
pre: " <b> 5.1. </b> "
---

## Giới thiệu

Trong workshop này, bạn sẽ xây dựng một **FastAPI Backend API** chạy trên AWS Lambda dưới dạng container image. Điều này thể hiện kiến trúc cloud-native hiện đại kết hợp serverless computing, công nghệ container, và các thực hành DevSecOps.

### Những gì bạn sẽ xây dựng

![Workshop Architecture](/images/5-Workshop/5.1-Workshop-overview/workshop-overview.png)

Khi hoàn thành workshop này, bạn sẽ có:

1. **Ứng dụng FastAPI**
   - RESTful API với 3 routers: auth, products, orders
   - Kiến trúc phân lớp: API → Service → Repository
   - Pydantic models cho validation dữ liệu
   - JWT-based authentication

2. **Lambda Container Deployment**
   - FastAPI đóng gói dưới dạng Docker container
   - Mangum adapter cho tương thích Lambda
   - Container image lưu trữ trong Amazon ECR

3. **Infrastructure as Code**
   - Terraform modules cho tất cả tài nguyên AWS
   - DynamoDB tables với GSI indexes
   - API Gateway HTTP API
   - IAM roles với least privilege

4. **CI/CD Pipeline**
   - GitLab CI hoặc AWS CodePipeline
   - Semgrep cho static code analysis
   - Trivy cho vulnerability scanning
   - Tự động deploy với Terraform

5. **Monitoring & Alerting**
   - CloudWatch log groups
   - Lambda error alarms
   - SNS notifications

### Luồng kiến trúc

```
┌─────────────────────────────────────────────────────────────────┐
│                        CI/CD Pipeline                            │
├─────────────────────────────────────────────────────────────────┤
│  Git Push → Semgrep → Docker Build → Trivy → ECR → Terraform   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      Runtime Architecture                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   Client → API Gateway (HTTP) → Lambda (Container)              │
│                                      ↓                           │
│                              ┌───────────────┐                   │
│                              │   Mangum      │                   │
│                              └───────┬───────┘                   │
│                                      ↓                           │
│                              ┌───────────────┐                   │
│                              │   FastAPI     │                   │
│                              │   ├── /auth   │                   │
│                              │   ├── /products                   │
│                              │   └── /orders │                   │
│                              └───────┬───────┘                   │
│                                      ↓                           │
│                    ┌─────────────────┼─────────────────┐        │
│                    ↓                 ↓                 ↓        │
│             ┌──────────┐     ┌──────────┐     ┌──────────┐      │
│             │ Products │     │  Orders  │     │  Users   │      │
│             │  Table   │     │  Table   │     │  Table   │      │
│             └──────────┘     └──────────┘     └──────────┘      │
│                           DynamoDB                               │
└─────────────────────────────────────────────────────────────────┘
```

### Công nghệ chính

| Thành phần | Công nghệ | Mục đích |
| --- | --- | --- |
| **Web Framework** | FastAPI | API Python async hiệu suất cao |
| **Lambda Adapter** | Mangum | ASGI adapter cho AWS Lambda |
| **Container** | Docker | Đóng gói ứng dụng với dependencies |
| **Database** | DynamoDB | NoSQL database với on-demand scaling |
| **Authentication** | JWT + Secrets Manager | Token-based auth bảo mật |
| **Infrastructure** | Terraform | Infrastructure as Code |
| **Security Scanning** | Semgrep, Trivy | SAST và vulnerability scanning |
| **CI/CD** | GitLab CI / CodePipeline | Tự động build và deploy |

### Cấu trúc ứng dụng FastAPI

```python
# backend/app/main.py
from fastapi import FastAPI
from app.api.routers.auth import router as auth_router
from app.api.routers.products import router as products_router
from app.api.routers.orders import router as orders_router

def create_app() -> FastAPI:
    app = FastAPI(title="Products & Orders API", version="1.0.0")
    
    @app.get("/health")
    async def health() -> dict:
        return {"status": "ok"}
    
    app.include_router(auth_router, prefix="/auth", tags=["auth"])
    app.include_router(products_router, prefix="/products", tags=["products"])
    app.include_router(orders_router, prefix="/orders", tags=["orders"])
    
    return app

app = create_app()
```

```python
# backend/app/lambda_handler.py
from mangum import Mangum
from app.main import app

handler = Mangum(app)  # Lambda handler cho API Gateway
```

### Cấu trúc Terraform Module

```hcl
# infra/main.tf
module "dynamodb" {
  source              = "./modules/dynamodb"
  products_table_name = var.products_table_name
  orders_table_name   = var.orders_table_name
  users_table_name    = var.users_table_name
}

module "iam" {
  source             = "./modules/iam"
  project_name       = var.project_name
  products_table_arn = module.dynamodb.products_table_arn
  orders_table_arn   = module.dynamodb.orders_table_arn
  users_table_arn    = module.dynamodb.users_table_arn
  jwt_secret_arn     = var.jwt_secret_arn
}

module "lambda" {
  source          = "./modules/lambda_container"
  project_name    = var.project_name
  lambda_role_arn = module.iam.lambda_role_arn
  image_uri       = var.image_uri
  environment = {
    APP_REGION     = var.region
    PRODUCTS_TABLE = module.dynamodb.products_table_name
    ORDERS_TABLE   = module.dynamodb.orders_table_name
    JWT_SECRET     = data.aws_secretsmanager_secret_version.jwt.secret_string
  }
}

module "apigw" {
  source       = "./modules/apigw"
  project_name = var.project_name
  lambda_arn   = module.lambda.lambda_arn
}

module "observability" {
  source       = "./modules/observability"
  project_name = var.project_name
  lambda_name  = module.lambda.lambda_name
}
```

### Mục tiêu học tập

Sau khi hoàn thành workshop này, bạn sẽ có thể:

- Xây dựng ứng dụng FastAPI production-ready
- Đóng gói Python apps thành Lambda container images
- Thiết kế kiến trúc phân lớp (API → Service → Repository)
- Triển khai JWT authentication mà không cần Cognito
- Sử dụng Terraform modules cho infrastructure tái sử dụng
- Tích hợp security scanning vào CI/CD pipelines
- Thiết lập monitoring và alerting cho ứng dụng serverless

### Kiến thức yêu cầu

- Lập trình Python cơ bản
- Hiểu về REST APIs
- Quen thuộc với Docker
- Kiến thức AWS cơ bản (Lambda, DynamoDB, IAM)

#### Ảnh cần thiết:
- `workshop-overview.png` - Sơ đồ kiến trúc tổng thể
