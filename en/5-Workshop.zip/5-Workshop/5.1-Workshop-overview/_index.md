﻿---
title: "Workshop Overview"
date: "2024-01-01"
weight: 1
chapter: false
pre: " <b> 5.1. </b> "
---

## Introduction

In this workshop, you will build a **FastAPI Backend API** running on AWS Lambda as a container image. This demonstrates modern cloud-native architecture combining serverless computing, container technology, and DevSecOps practices.

### What You Will Build

![Workshop Architecture](/images/5-Workshop/5.1-Workshop-overview/workshop-overview.png)

By the end of this workshop, you will have:

1. **FastAPI Application**
   - RESTful API with 3 routers: auth, products, orders
   - Layered architecture: API → Service → Repository
   - Pydantic models for data validation
   - JWT-based authentication

2. **Lambda Container Deployment**
   - FastAPI packaged as Docker container
   - Mangum adapter for Lambda compatibility
   - Container image stored in Amazon ECR

3. **Infrastructure as Code**
   - Terraform modules for all AWS resources
   - DynamoDB tables with GSI indexes
   - API Gateway HTTP API
   - IAM roles with least privilege

4. **CI/CD Pipeline**
   - GitLab CI or AWS CodePipeline
   - Semgrep for static code analysis
   - Trivy for vulnerability scanning
   - Automated deployment with Terraform

5. **Monitoring & Alerting**
   - CloudWatch log groups
   - Lambda error alarms
   - SNS notifications

### Architecture Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        CI/CD Pipeline                            │
├─────────────────────────────────────────────────────────────────┤
│  Git Push → Semgrep → Docker Build → Trivy → ECR → Terraform   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      Runtime Architecture                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   Client → API Gateway (HTTP) → Lambda (Container)              │
│                                      ↓                           │
│                              ┌───────────────┐                   │
│                              │   Mangum      │                   │
│                              └───────┬───────┘                   │
│                                      ↓                           │
│                              ┌───────────────┐                   │
│                              │   FastAPI     │                   │
│                              │   ├── /auth   │                   │
│                              │   ├── /products                   │
│                              │   └── /orders │                   │
│                              └───────┬───────┘                   │
│                                      ↓                           │
│                    ┌─────────────────┼─────────────────┐        │
│                    ↓                 ↓                 ↓        │
│             ┌──────────┐     ┌──────────┐     ┌──────────┐      │
│             │ Products │     │  Orders  │     │  Users   │      │
│             │  Table   │     │  Table   │     │  Table   │      │
│             └──────────┘     └──────────┘     └──────────┘      │
│                           DynamoDB                               │
└─────────────────────────────────────────────────────────────────┘
```

### Key Technologies

| Component | Technology | Purpose |
| --- | --- | --- |
| **Web Framework** | FastAPI | High-performance async Python API |
| **Lambda Adapter** | Mangum | ASGI adapter for AWS Lambda |
| **Container** | Docker | Package application with dependencies |
| **Database** | DynamoDB | NoSQL database with on-demand scaling |
| **Authentication** | JWT + Secrets Manager | Secure token-based auth |
| **Infrastructure** | Terraform | Infrastructure as Code |
| **Security Scanning** | Semgrep, Trivy | SAST and vulnerability scanning |
| **CI/CD** | GitLab CI / CodePipeline | Automated build and deploy |

### FastAPI Application Structure

```python
# backend/app/main.py
from fastapi import FastAPI
from app.api.routers.auth import router as auth_router
from app.api.routers.products import router as products_router
from app.api.routers.orders import router as orders_router

def create_app() -> FastAPI:
    app = FastAPI(title="Products & Orders API", version="1.0.0")
    
    @app.get("/health")
    async def health() -> dict:
        return {"status": "ok"}
    
    app.include_router(auth_router, prefix="/auth", tags=["auth"])
    app.include_router(products_router, prefix="/products", tags=["products"])
    app.include_router(orders_router, prefix="/orders", tags=["orders"])
    
    return app

app = create_app()
```

```python
# backend/app/lambda_handler.py
from mangum import Mangum
from app.main import app

handler = Mangum(app)  # Lambda handler for API Gateway
```

### Terraform Module Structure

```hcl
# infra/main.tf
module "dynamodb" {
  source              = "./modules/dynamodb"
  products_table_name = var.products_table_name
  orders_table_name   = var.orders_table_name
  users_table_name    = var.users_table_name
}

module "iam" {
  source             = "./modules/iam"
  project_name       = var.project_name
  products_table_arn = module.dynamodb.products_table_arn
  orders_table_arn   = module.dynamodb.orders_table_arn
  users_table_arn    = module.dynamodb.users_table_arn
  jwt_secret_arn     = var.jwt_secret_arn
}

module "lambda" {
  source          = "./modules/lambda_container"
  project_name    = var.project_name
  lambda_role_arn = module.iam.lambda_role_arn
  image_uri       = var.image_uri
  environment = {
    APP_REGION     = var.region
    PRODUCTS_TABLE = module.dynamodb.products_table_name
    ORDERS_TABLE   = module.dynamodb.orders_table_name
    JWT_SECRET     = data.aws_secretsmanager_secret_version.jwt.secret_string
  }
}

module "apigw" {
  source       = "./modules/apigw"
  project_name = var.project_name
  lambda_arn   = module.lambda.lambda_arn
}

module "observability" {
  source       = "./modules/observability"
  project_name = var.project_name
  lambda_name  = module.lambda.lambda_name
}
```

### Learning Objectives

After completing this workshop, you will be able to:

- Build production-ready FastAPI applications
- Package Python apps as Lambda container images
- Design layered architecture (API → Service → Repository)
- Implement JWT authentication without Cognito
- Use Terraform modules for reusable infrastructure
- Integrate security scanning into CI/CD pipelines
- Set up monitoring and alerting for serverless applications

### Prerequisites Knowledge

- Basic Python programming
- Understanding of REST APIs
- Familiarity with Docker
- Basic AWS knowledge (Lambda, DynamoDB, IAM)

#### Images Required:
- `workshop-overview.png` - Overall architecture diagram
