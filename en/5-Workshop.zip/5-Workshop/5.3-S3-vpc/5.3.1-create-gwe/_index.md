﻿---
title: "Create CodePipeline and CodeBuild"
date: "2024-01-01"
weight: 1
chapter: false
pre: " <b> 5.3.1. </b> "
---

## Create CodePipeline and CodeBuild

In this section, you will create the AWS CodePipeline and CodeBuild resources to automate your CI/CD workflow.

### Step 1: Create IAM Roles

First, create the necessary IAM roles for CodePipeline and CodeBuild.

#### 1.1 Create CodePipeline Role

Navigate to **IAM Console** → **Roles** → **Create Role**

![Create CodePipeline Role](/images/5-Workshop/5.3-CICD/5.3.1/codepipeline-role.png)

Select the following:
- **Trusted entity type**: AWS service
- **Use case**: CodePipeline
- **Permissions**: Attach the following policies:
  - `AWSCodePipelineFullAccess`
  - `AmazonS3FullAccess`
  - `AWSCodeBuildAdminAccess`

#### 1.2 Create CodeBuild Role

Create another role for CodeBuild:

- **Trusted entity type**: AWS service
- **Use case**: CodeBuild
- **Permissions**: Attach the following policies:
  - `AWSCodeBuildAdminAccess`
  - `AmazonEC2ContainerRegistryFullAccess`
  - `AmazonS3FullAccess`
  - `CloudWatchLogsFullAccess`
  - `SecretsManagerReadWrite`

### Step 2: Create S3 Bucket for Artifacts

Create an S3 bucket to store pipeline artifacts:

```bash
aws s3 mb s3://secure-serverless-artifacts-$(aws sts get-caller-identity --query Account --output text) --region ap-southeast-1
```

![S3 Artifact Bucket](/images/5-Workshop/5.3-CICD/5.3.1/s3-artifact-bucket.png)

### Step 3: Create ECR Repository

Create an ECR repository for container images:

```bash
aws ecr create-repository \
    --repository-name secure-serverless-app \
    --image-scanning-configuration scanOnPush=true \
    --region ap-southeast-1
```

![ECR Repository](/images/5-Workshop/5.3-CICD/5.3.1/ecr-repository.png)

### Step 4: Create CodeBuild Project

Navigate to **CodeBuild Console** → **Create build project**

Configure the following:

| Setting | Value |
| --- | --- |
| **Project name** | secure-serverless-build |
| **Source provider** | GitLab |
| **Environment image** | Managed image |
| **Operating system** | Amazon Linux 2 |
| **Runtime** | Standard |
| **Image** | aws/codebuild/amazonlinux2-x86_64-standard:4.0 |
| **Privileged** | Enabled (for Docker builds) |
| **Service role** | CodeBuild role created earlier |
| **Buildspec** | Use a buildspec file |

![CodeBuild Project](/images/5-Workshop/5.3-CICD/5.3.1/codebuild-project.png)

#### buildspec.yml

Create the buildspec file in your repository:

```yaml
version: 0.2

env:
  variables:
    AWS_DEFAULT_REGION: ap-southeast-1
  secrets-manager:
    GITLAB_TOKEN: "gitlab-credentials:token"

phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $ECR_REPO_URI
      - COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)
      - IMAGE_TAG=${COMMIT_HASH:=latest}
      
  build:
    commands:
      - echo Build started on `date`
      - echo Building the Docker image...
      - docker build -t $ECR_REPO_URI:latest .
      - docker tag $ECR_REPO_URI:latest $ECR_REPO_URI:$IMAGE_TAG
      
  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker image...
      - docker push $ECR_REPO_URI:latest
      - docker push $ECR_REPO_URI:$IMAGE_TAG
      - printf '{"ImageURI":"%s"}' $ECR_REPO_URI:$IMAGE_TAG > imageDetail.json

artifacts:
  files:
    - imageDetail.json
    - appspec.yml
    - taskdef.json
```

### Step 5: Create CodePipeline

Navigate to **CodePipeline Console** → **Create pipeline**

#### 5.1 Pipeline Settings

| Setting | Value |
| --- | --- |
| **Pipeline name** | secure-serverless-pipeline |
| **Service role** | New service role or existing CodePipeline role |
| **Artifact store** | Custom location (S3 bucket created earlier) |

#### 5.2 Source Stage

| Setting | Value |
| --- | --- |
| **Source provider** | GitLab |
| **Connection** | Create new connection or use existing |
| **Repository name** | your-gitlab-repo |
| **Branch name** | main |

![Source Stage](/images/5-Workshop/5.3-CICD/5.3.1/source-stage.png)

#### 5.3 Build Stage

| Setting | Value |
| --- | --- |
| **Build provider** | AWS CodeBuild |
| **Region** | Asia Pacific (Singapore) |
| **Project name** | secure-serverless-build |

#### 5.4 Deploy Stage

| Setting | Value |
| --- | --- |
| **Deploy provider** | AWS Lambda |
| **Function name** | Your Lambda function name |
| **Input artifacts** | BuildArtifact |

![Pipeline Overview](/images/5-Workshop/5.3-CICD/5.3.1/pipeline-overview.png)

### Step 6: Verify Pipeline

1. Push code to your GitLab repository
2. Navigate to CodePipeline console
3. Verify that the pipeline is triggered and runs successfully

![Pipeline Execution](/images/5-Workshop/5.3-CICD/5.3.1/pipeline-execution.png)

{{% notice tip %}}
You can view detailed logs of each stage by clicking on the stage name and then "View logs" in CloudWatch.
{{% /notice %}}

#### Images Required:
- `codepipeline-role.png` - IAM role creation for CodePipeline
- `s3-artifact-bucket.png` - S3 bucket for artifacts
- `ecr-repository.png` - ECR repository creation
- `codebuild-project.png` - CodeBuild project configuration
- `source-stage.png` - Pipeline source stage configuration
- `pipeline-overview.png` - Complete pipeline overview
- `pipeline-execution.png` - Successful pipeline execution
