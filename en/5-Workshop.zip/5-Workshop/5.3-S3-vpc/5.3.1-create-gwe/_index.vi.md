﻿---
title: "Tạo CodePipeline và CodeBuild"
date: "2024-01-01"
weight: 1
chapter: false
pre: " <b> 5.3.1. </b> "
---

## Tạo CodePipeline và CodeBuild

Trong phần này, bạn sẽ tạo các tài nguyên AWS CodePipeline và CodeBuild để tự động hóa quy trình CI/CD.

### Bước 1: Tạo IAM Roles

Đầu tiên, tạo các IAM roles cần thiết cho CodePipeline và CodeBuild.

#### 1.1 Tạo CodePipeline Role

Điều hướng đến **IAM Console** → **Roles** → **Create Role**

![Create CodePipeline Role](/images/5-Workshop/5.3-CICD/5.3.1/codepipeline-role.png)

Chọn các mục sau:
- **Trusted entity type**: AWS service
- **Use case**: CodePipeline
- **Permissions**: Gắn các policies sau:
  - `AWSCodePipelineFullAccess`
  - `AmazonS3FullAccess`
  - `AWSCodeBuildAdminAccess`

#### 1.2 Tạo CodeBuild Role

Tạo role khác cho CodeBuild:

- **Trusted entity type**: AWS service
- **Use case**: CodeBuild
- **Permissions**: Gắn các policies sau:
  - `AWSCodeBuildAdminAccess`
  - `AmazonEC2ContainerRegistryFullAccess`
  - `AmazonS3FullAccess`
  - `CloudWatchLogsFullAccess`
  - `SecretsManagerReadWrite`

### Bước 2: Tạo S3 Bucket cho Artifacts

Tạo S3 bucket để lưu trữ pipeline artifacts:

```bash
aws s3 mb s3://secure-serverless-artifacts-$(aws sts get-caller-identity --query Account --output text) --region ap-southeast-1
```

![S3 Artifact Bucket](/images/5-Workshop/5.3-CICD/5.3.1/s3-artifact-bucket.png)

### Bước 3: Tạo ECR Repository

Tạo ECR repository cho container images:

```bash
aws ecr create-repository \
    --repository-name secure-serverless-app \
    --image-scanning-configuration scanOnPush=true \
    --region ap-southeast-1
```

![ECR Repository](/images/5-Workshop/5.3-CICD/5.3.1/ecr-repository.png)

### Bước 4: Tạo CodeBuild Project

Điều hướng đến **CodeBuild Console** → **Create build project**

Cấu hình như sau:

| Cài đặt | Giá trị |
| --- | --- |
| **Project name** | secure-serverless-build |
| **Source provider** | GitLab |
| **Environment image** | Managed image |
| **Operating system** | Amazon Linux 2 |
| **Runtime** | Standard |
| **Image** | aws/codebuild/amazonlinux2-x86_64-standard:4.0 |
| **Privileged** | Enabled (cho Docker builds) |
| **Service role** | CodeBuild role đã tạo trước đó |
| **Buildspec** | Use a buildspec file |

![CodeBuild Project](/images/5-Workshop/5.3-CICD/5.3.1/codebuild-project.png)

#### buildspec.yml

Tạo file buildspec trong repository của bạn:

```yaml
version: 0.2

env:
  variables:
    AWS_DEFAULT_REGION: ap-southeast-1
  secrets-manager:
    GITLAB_TOKEN: "gitlab-credentials:token"

phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $ECR_REPO_URI
      - COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)
      - IMAGE_TAG=${COMMIT_HASH:=latest}
      
  build:
    commands:
      - echo Build started on `date`
      - echo Building the Docker image...
      - docker build -t $ECR_REPO_URI:latest .
      - docker tag $ECR_REPO_URI:latest $ECR_REPO_URI:$IMAGE_TAG
      
  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker image...
      - docker push $ECR_REPO_URI:latest
      - docker push $ECR_REPO_URI:$IMAGE_TAG
      - printf '{"ImageURI":"%s"}' $ECR_REPO_URI:$IMAGE_TAG > imageDetail.json

artifacts:
  files:
    - imageDetail.json
    - appspec.yml
    - taskdef.json
```

### Bước 5: Tạo CodePipeline

Điều hướng đến **CodePipeline Console** → **Create pipeline**

#### 5.1 Pipeline Settings

| Cài đặt | Giá trị |
| --- | --- |
| **Pipeline name** | secure-serverless-pipeline |
| **Service role** | New service role hoặc existing CodePipeline role |
| **Artifact store** | Custom location (S3 bucket đã tạo trước đó) |

#### 5.2 Source Stage

| Cài đặt | Giá trị |
| --- | --- |
| **Source provider** | GitLab |
| **Connection** | Tạo connection mới hoặc sử dụng existing |
| **Repository name** | your-gitlab-repo |
| **Branch name** | main |

![Source Stage](/images/5-Workshop/5.3-CICD/5.3.1/source-stage.png)

#### 5.3 Build Stage

| Cài đặt | Giá trị |
| --- | --- |
| **Build provider** | AWS CodeBuild |
| **Region** | Asia Pacific (Singapore) |
| **Project name** | secure-serverless-build |

#### 5.4 Deploy Stage

| Cài đặt | Giá trị |
| --- | --- |
| **Deploy provider** | AWS Lambda |
| **Function name** | Tên Lambda function của bạn |
| **Input artifacts** | BuildArtifact |

![Pipeline Overview](/images/5-Workshop/5.3-CICD/5.3.1/pipeline-overview.png)

### Bước 6: Xác minh Pipeline

1. Push code lên GitLab repository của bạn
2. Điều hướng đến CodePipeline console
3. Xác minh rằng pipeline được trigger và chạy thành công

![Pipeline Execution](/images/5-Workshop/5.3-CICD/5.3.1/pipeline-execution.png)

{{% notice tip %}}
Bạn có thể xem logs chi tiết của mỗi stage bằng cách click vào tên stage và sau đó "View logs" trong CloudWatch.
{{% /notice %}}

#### Ảnh cần thiết:
- `codepipeline-role.png` - Tạo IAM role cho CodePipeline
- `s3-artifact-bucket.png` - S3 bucket cho artifacts
- `ecr-repository.png` - Tạo ECR repository
- `codebuild-project.png` - Cấu hình CodeBuild project
- `source-stage.png` - Cấu hình source stage của pipeline
- `pipeline-overview.png` - Tổng quan pipeline hoàn chỉnh
- `pipeline-execution.png` - Thực thi pipeline thành công
