﻿---
title: "Thiết lập Pipeline CI/CD"
date: "2024-01-01"
weight: 3
chapter: false
pre: " <b> 5.3. </b> "
---

## Thiết lập Pipeline CI/CD

Trong phần này, bạn sẽ thiết lập pipeline CI/CD sử dụng AWS CodePipeline và CodeBuild để tự động hóa việc build, scan, và deploy ứng dụng FastAPI của bạn.

![CI/CD Pipeline Architecture](/images/5-Workshop/5.3-CICD/cicd-architecture.png)

### Tổng quan Pipeline

Pipeline CI/CD bao gồm các stage sau:

| Stage | Công cụ | Mục đích |
| --- | --- | --- |
| **Lint** | Semgrep | Static Application Security Testing (SAST) |
| **Build** | CodeBuild + Docker | Build container image |
| **Scan** | Trivy | Scan filesystem và container cho vulnerabilities |
| **Push** | ECR | Lưu trữ container image |
| **Deploy** | Terraform | Provision/update infrastructure |

### Nội dung

1. [Tạo CodeBuild Projects](5.3.1-create-gwe/)
2. [Cấu hình Security Scanning](5.3.2-test-gwe/)

### Luồng Pipeline

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  Git Push   │───▶│  CodeBuild  │───▶│  CodeBuild  │
│  (Source)   │    │   (Build)   │    │  (Deploy)   │
└─────────────┘    └─────────────┘    └─────────────┘
                          │
         ┌────────────────┼────────────────┐
         ▼                ▼                ▼
   ┌──────────┐    ┌──────────┐    ┌──────────┐
   │ Semgrep  │    │  Docker  │    │  Trivy   │
   │  (SAST)  │    │  Build   │    │  (Scan)  │
   └──────────┘    └──────────┘    └──────────┘
                          │
                          ▼
                   ┌──────────┐
                   │   ECR    │
                   │  (Push)  │
                   └──────────┘
                          │
                          ▼
                   ┌──────────┐
                   │Terraform │
                   │ (Deploy) │
                   └──────────┘
```

### Build Stage - buildspec-build.yml

Đây là file buildspec thực tế từ dự án:

```yaml
version: 0.2
env:
  variables:
    IMAGE_NAME: "fastapi-lambda"
    IMAGE_TAG: "latest"
phases:
  install:
    runtime-versions:
      docker: 20
    commands:
      - pip3 install semgrep trivy
  pre_build:
    commands:
      - echo "Running Semgrep..."
      - semgrep --config backend/semgrep.yml || exit 1
  build:
    commands:
      - echo "Docker build..."
      - docker build -t ${IMAGE_NAME}:${IMAGE_TAG} backend
      - echo "Scanning filesystem with Trivy..."
      - trivy fs --exit-code 1 --severity HIGH,CRITICAL --ignorefile backend/trivyignore.txt . || exit 1
      - echo "Scanning image with Trivy..."
      - trivy image --exit-code 1 --severity HIGH,CRITICAL ${IMAGE_NAME}:${IMAGE_TAG} || exit 1
  post_build:
    commands:
      - echo "Logging in to ECR..."
      - aws ecr get-login-password | docker login --username AWS --password-stdin ${ECR_URI}
      - docker tag ${IMAGE_NAME}:${IMAGE_TAG} ${ECR_URI}/${IMAGE_NAME}:${IMAGE_TAG}
      - docker push ${ECR_URI}/${IMAGE_NAME}:${IMAGE_TAG}
artifacts:
  files:
    - image-detail.json
cache:
  paths:
    - '/root/.cache/semgrep/**'
    - '/root/.cache/trivy/**'
```

### Deploy Stage - buildspec-deploy.yml

```yaml
version: 0.2
phases:
  install:
    commands:
      - curl -fsSL https://releases.hashicorp.com/terraform/1.9.5/terraform_1.9.5_linux_amd64.zip -o tf.zip
      - unzip -o tf.zip -d /usr/local/bin
      - terraform -v
  pre_build:
    commands:
      - cd infra
      - terraform init -upgrade
  build:
    commands:
      - terraform plan -input=false -out=tfplan
      - terraform apply -auto-approve tfplan
  post_build:
    commands:
      - echo "Deployment finished"
```

### Cấu hình Semgrep

Dự án sử dụng custom Semgrep rules cho security scanning:

```yaml
# backend/semgrep.yml
rules:
  - id: jwt-hardcoded-secret
    message: Avoid hardcoding JWT secrets; use Secrets Manager/env.
    severity: ERROR
    languages: [python]
    pattern: |
      jwt.encode($P, $S, ...)
    metavariable-pattern:
      metavariable: $S
      pattern: "'$SECRET'"
      
  - id: fastapi-debug
    message: Do not run uvicorn with reload or debug in production.
    severity: WARNING
    languages: [python]
    pattern-either:
      - pattern: uvicorn.run(..., reload=True, ...)
      - pattern: uvicorn.run(..., debug=True, ...)
```

### Dockerfile cho Lambda Container

```dockerfile
# backend/Dockerfile
# Lambda base image for Python 3.10
FROM public.ecr.aws/lambda/python:3.10

# Copy và install requirements
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt -t "${LAMBDA_TASK_ROOT}"

# Copy application code
COPY app/ ${LAMBDA_TASK_ROOT}/app/

# Set the handler
CMD ["app.lambda_handler.handler"]
```

### Dependencies chính (requirements.txt)

```
fastapi>=0.100.0
mangum>=0.17.0
boto3>=1.28.0
pydantic>=2.0.0
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
uvicorn>=0.23.0
```

{{% notice tip %}}
Pipeline sử dụng Semgrep cho static code analysis và Trivy cho cả filesystem và container image scanning. Điều này cung cấp defense-in-depth security scanning tại nhiều stages.
{{% /notice %}}

#### Ảnh cần thiết:
- `cicd-architecture.png` - Kiến trúc CI/CD pipeline
- `codebuild-console.png` - CodeBuild project console
- `ecr-repository.png` - ECR repository với images
- `pipeline-success.png` - Thực thi pipeline thành công
