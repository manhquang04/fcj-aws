﻿---
title: "Setting up CI/CD Pipeline"
date: "2024-01-01"
weight: 3
chapter: false
pre: " <b> 5.3. </b> "
---

## Setting up CI/CD Pipeline

In this section, you will set up a CI/CD pipeline using AWS CodePipeline and CodeBuild to automate building, scanning, and deploying your FastAPI application.

![CI/CD Pipeline Architecture](/images/5-Workshop/5.3-CICD/cicd-architecture.png)

### Pipeline Overview

The CI/CD pipeline consists of the following stages:

| Stage | Tool | Purpose |
| --- | --- | --- |
| **Lint** | Semgrep | Static Application Security Testing (SAST) |
| **Build** | CodeBuild + Docker | Build container image |
| **Scan** | Trivy | Scan filesystem and container for vulnerabilities |
| **Push** | ECR | Store container image |
| **Deploy** | Terraform | Provision/update infrastructure |

### Content

1. [Create CodeBuild Projects](5.3.1-create-gwe/)
2. [Configure Security Scanning](5.3.2-test-gwe/)

### Pipeline Flow

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  Git Push   │───▶│  CodeBuild  │───▶│  CodeBuild  │
│  (Source)   │    │   (Build)   │    │  (Deploy)   │
└─────────────┘    └─────────────┘    └─────────────┘
                          │
         ┌────────────────┼────────────────┐
         ▼                ▼                ▼
   ┌──────────┐    ┌──────────┐    ┌──────────┐
   │ Semgrep  │    │  Docker  │    │  Trivy   │
   │  (SAST)  │    │  Build   │    │  (Scan)  │
   └──────────┘    └──────────┘    └──────────┘
                          │
                          ▼
                   ┌──────────┐
                   │   ECR    │
                   │  (Push)  │
                   └──────────┘
                          │
                          ▼
                   ┌──────────┐
                   │Terraform │
                   │ (Deploy) │
                   └──────────┘
```

### Build Stage - buildspec-build.yml

This is the actual buildspec file from the project:

```yaml
version: 0.2
env:
  variables:
    IMAGE_NAME: "fastapi-lambda"
    IMAGE_TAG: "latest"
phases:
  install:
    runtime-versions:
      docker: 20
    commands:
      - pip3 install semgrep trivy
  pre_build:
    commands:
      - echo "Running Semgrep..."
      - semgrep --config backend/semgrep.yml || exit 1
  build:
    commands:
      - echo "Docker build..."
      - docker build -t ${IMAGE_NAME}:${IMAGE_TAG} backend
      - echo "Scanning filesystem with Trivy..."
      - trivy fs --exit-code 1 --severity HIGH,CRITICAL --ignorefile backend/trivyignore.txt . || exit 1
      - echo "Scanning image with Trivy..."
      - trivy image --exit-code 1 --severity HIGH,CRITICAL ${IMAGE_NAME}:${IMAGE_TAG} || exit 1
  post_build:
    commands:
      - echo "Logging in to ECR..."
      - aws ecr get-login-password | docker login --username AWS --password-stdin ${ECR_URI}
      - docker tag ${IMAGE_NAME}:${IMAGE_TAG} ${ECR_URI}/${IMAGE_NAME}:${IMAGE_TAG}
      - docker push ${ECR_URI}/${IMAGE_NAME}:${IMAGE_TAG}
artifacts:
  files:
    - image-detail.json
cache:
  paths:
    - '/root/.cache/semgrep/**'
    - '/root/.cache/trivy/**'
```

### Deploy Stage - buildspec-deploy.yml

```yaml
version: 0.2
phases:
  install:
    commands:
      - curl -fsSL https://releases.hashicorp.com/terraform/1.9.5/terraform_1.9.5_linux_amd64.zip -o tf.zip
      - unzip -o tf.zip -d /usr/local/bin
      - terraform -v
  pre_build:
    commands:
      - cd infra
      - terraform init -upgrade
  build:
    commands:
      - terraform plan -input=false -out=tfplan
      - terraform apply -auto-approve tfplan
  post_build:
    commands:
      - echo "Deployment finished"
```

### Semgrep Configuration

The project uses custom Semgrep rules for security scanning:

```yaml
# backend/semgrep.yml
rules:
  - id: jwt-hardcoded-secret
    message: Avoid hardcoding JWT secrets; use Secrets Manager/env.
    severity: ERROR
    languages: [python]
    pattern: |
      jwt.encode($P, $S, ...)
    metavariable-pattern:
      metavariable: $S
      pattern: "'$SECRET'"
      
  - id: fastapi-debug
    message: Do not run uvicorn with reload or debug in production.
    severity: WARNING
    languages: [python]
    pattern-either:
      - pattern: uvicorn.run(..., reload=True, ...)
      - pattern: uvicorn.run(..., debug=True, ...)
```

### Dockerfile for Lambda Container

```dockerfile
# backend/Dockerfile
# Lambda base image for Python 3.10
FROM public.ecr.aws/lambda/python:3.10

# Copy and install requirements
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt -t "${LAMBDA_TASK_ROOT}"

# Copy application code
COPY app/ ${LAMBDA_TASK_ROOT}/app/

# Set the handler
CMD ["app.lambda_handler.handler"]
```

### Key Dependencies (requirements.txt)

```
fastapi>=0.100.0
mangum>=0.17.0
boto3>=1.28.0
pydantic>=2.0.0
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
uvicorn>=0.23.0
```

{{% notice tip %}}
The pipeline uses Semgrep for static code analysis and Trivy for both filesystem and container image scanning. This provides defense-in-depth security scanning at multiple stages.
{{% /notice %}}

#### Images Required:
- `cicd-architecture.png` - CI/CD pipeline architecture
- `codebuild-console.png` - CodeBuild project console
- `ecr-repository.png` - ECR repository with images
- `pipeline-success.png` - Successful pipeline execution
