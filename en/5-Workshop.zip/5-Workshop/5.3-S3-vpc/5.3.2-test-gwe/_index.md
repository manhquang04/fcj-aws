﻿---
title: "Configure Security Scanning"
date: "2024-01-01"
weight: 2
chapter: false
pre: " <b> 5.3.2. </b> "
---

## Configure Security Scanning with Semgrep and Trivy

In this section, you will integrate security scanning tools into your CI/CD pipeline to automatically detect vulnerabilities.

![Security Scanning Flow](/images/5-Workshop/5.3-CICD/5.3.2/security-scanning-flow.png)

### Overview

| Tool | Purpose | Scan Type |
| --- | --- | --- |
| **Semgrep** | Static Application Security Testing | Source code |
| **Trivy** | Container Vulnerability Scanner | Container images |

### Step 1: Configure Semgrep

Semgrep is a fast, open-source static analysis tool that finds bugs and enforces code standards.

#### 1.1 Create Semgrep Configuration

Create `.semgrep.yml` in your repository root:

```yaml
rules:
  - id: hardcoded-aws-credentials
    patterns:
      - pattern-either:
          - pattern: AKIA...
          - pattern: aws_access_key_id = "..."
          - pattern: aws_secret_access_key = "..."
    message: "Hardcoded AWS credentials detected"
    languages: [python, javascript, typescript, yaml]
    severity: ERROR

  - id: sql-injection
    patterns:
      - pattern: |
          $QUERY = "..." + $USER_INPUT + "..."
          $DB.execute($QUERY)
    message: "Potential SQL injection vulnerability"
    languages: [python]
    severity: ERROR

  - id: insecure-lambda-permissions
    patterns:
      - pattern: |
          Effect: Allow
          Action: "*"
          Resource: "*"
    message: "Overly permissive Lambda IAM policy"
    languages: [yaml]
    severity: WARNING
```

#### 1.2 Add Semgrep to CodeBuild

Update your `buildspec.yml` to include Semgrep scanning:

```yaml
version: 0.2

phases:
  install:
    commands:
      - pip install semgrep

  pre_build:
    commands:
      - echo "Running Semgrep security scan..."
      - semgrep --config=auto --config=.semgrep.yml --error --json --output=semgrep-results.json . || true
      - |
        if [ -s semgrep-results.json ]; then
          echo "Security vulnerabilities found!"
          cat semgrep-results.json
          SEVERITY=$(jq '.results[].extra.severity' semgrep-results.json | grep -c "ERROR" || true)
          if [ "$SEVERITY" -gt "0" ]; then
            echo "Critical vulnerabilities detected. Failing build."
            exit 1
          fi
        fi
      - echo "Semgrep scan completed"
```

![Semgrep Results](/images/5-Workshop/5.3-CICD/5.3.2/semgrep-results.png)

### Step 2: Configure Trivy

Trivy is a comprehensive security scanner for containers, detecting vulnerabilities in OS packages and application dependencies.

#### 2.1 Add Trivy to CodeBuild

Update your `buildspec.yml` to include Trivy scanning:

```yaml
version: 0.2

phases:
  install:
    commands:
      - pip install semgrep
      - curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b /usr/local/bin

  pre_build:
    commands:
      # Semgrep scan
      - echo "Running Semgrep security scan..."
      - semgrep --config=auto --error . || exit 1
      
      # ECR login
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $ECR_REPO_URI

  build:
    commands:
      - echo "Building Docker image..."
      - docker build -t $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION .

  post_build:
    commands:
      # Trivy scan
      - echo "Running Trivy container scan..."
      - trivy image --exit-code 0 --severity LOW,MEDIUM --format json --output trivy-low-medium.json $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION
      - trivy image --exit-code 1 --severity HIGH,CRITICAL --format json --output trivy-high-critical.json $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION
      
      # Push image if scan passes
      - docker push $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION

artifacts:
  files:
    - semgrep-results.json
    - trivy-low-medium.json
    - trivy-high-critical.json
```

![Trivy Scan Results](/images/5-Workshop/5.3-CICD/5.3.2/trivy-results.png)

### Step 3: Create Security Reports Dashboard

#### 3.1 Store Reports in S3

Add the following to your buildspec to store security reports:

```yaml
artifacts:
  files:
    - semgrep-results.json
    - trivy-*.json
  name: security-reports-$CODEBUILD_BUILD_NUMBER
  
reports:
  security-report:
    files:
      - semgrep-results.json
      - trivy-high-critical.json
    file-format: GENERICJSON
```

#### 3.2 Set Up CloudWatch Metrics

Create CloudWatch metrics for security findings:

```bash
# Create custom metric for security findings
aws cloudwatch put-metric-data \
    --namespace "SecurityScanning" \
    --metric-name "HighSeverityFindings" \
    --value 0 \
    --dimensions Pipeline=secure-serverless-pipeline
```

### Step 4: Configure Failure Thresholds

Create a security policy that fails builds based on severity:

| Severity | Action |
| --- | --- |
| **CRITICAL** | Fail build immediately |
| **HIGH** | Fail build immediately |
| **MEDIUM** | Warning, allow build to continue |
| **LOW** | Informational only |

#### Example Policy Implementation

```yaml
# security-policy.yml
thresholds:
  critical: 0  # Zero tolerance for critical
  high: 0      # Zero tolerance for high
  medium: 10   # Allow up to 10 medium
  low: 50      # Allow up to 50 low
  
actions:
  on_critical: block
  on_high: block
  on_medium: warn
  on_low: info
```

### Step 5: Verify Security Scanning

1. Push code with a deliberate vulnerability (for testing):

```python
# test_vulnerability.py (DO NOT USE IN PRODUCTION)
import os
password = "hardcoded_password_123"  # This should trigger Semgrep
```

2. Check the CodeBuild logs for security findings
3. Verify that the build fails due to security violations

![Security Scan Failure](/images/5-Workshop/5.3-CICD/5.3.2/security-scan-failure.png)

### Best Practices

{{% notice tip %}}
**Security Scanning Best Practices:**
- Run security scans early in the pipeline (shift-left security)
- Set appropriate severity thresholds based on your risk tolerance
- Regularly update Semgrep rules and Trivy database
- Review and address all findings, even low severity ones
- Store security reports for compliance and auditing
{{% /notice %}}

#### Images Required:
- `security-scanning-flow.png` - Security scanning workflow diagram
- `semgrep-results.png` - Example Semgrep scan results
- `trivy-results.png` - Example Trivy scan results
- `security-scan-failure.png` - Build failure due to security issues
- `security-dashboard.png` - CloudWatch security metrics dashboard
