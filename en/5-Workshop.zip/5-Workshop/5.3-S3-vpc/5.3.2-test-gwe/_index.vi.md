﻿---
title: "Cấu hình quét bảo mật"
date: "2024-01-01"
weight: 2
chapter: false
pre: " <b> 5.3.2. </b> "
---

## Cấu hình quét bảo mật với Semgrep và Trivy

Trong phần này, bạn sẽ tích hợp các công cụ quét bảo mật vào pipeline CI/CD để tự động phát hiện lỗ hổng.

![Security Scanning Flow](/images/5-Workshop/5.3-CICD/5.3.2/security-scanning-flow.png)

### Tổng quan

| Công cụ | Mục đích | Loại quét |
| --- | --- | --- |
| **Semgrep** | Static Application Security Testing | Mã nguồn |
| **Trivy** | Container Vulnerability Scanner | Container images |

### Bước 1: Cấu hình Semgrep

Semgrep là công cụ phân tích tĩnh nhanh, mã nguồn mở giúp tìm bugs và áp dụng các tiêu chuẩn code.

#### 1.1 Tạo cấu hình Semgrep

Tạo `.semgrep.yml` trong thư mục gốc repository:

```yaml
rules:
  - id: hardcoded-aws-credentials
    patterns:
      - pattern-either:
          - pattern: AKIA...
          - pattern: aws_access_key_id = "..."
          - pattern: aws_secret_access_key = "..."
    message: "Phát hiện AWS credentials được hardcode"
    languages: [python, javascript, typescript, yaml]
    severity: ERROR

  - id: sql-injection
    patterns:
      - pattern: |
          $QUERY = "..." + $USER_INPUT + "..."
          $DB.execute($QUERY)
    message: "Lỗ hổng SQL injection tiềm ẩn"
    languages: [python]
    severity: ERROR

  - id: insecure-lambda-permissions
    patterns:
      - pattern: |
          Effect: Allow
          Action: "*"
          Resource: "*"
    message: "IAM policy Lambda quá rộng quyền"
    languages: [yaml]
    severity: WARNING
```

#### 1.2 Thêm Semgrep vào CodeBuild

Cập nhật `buildspec.yml` để bao gồm quét Semgrep:

```yaml
version: 0.2

phases:
  install:
    commands:
      - pip install semgrep

  pre_build:
    commands:
      - echo "Running Semgrep security scan..."
      - semgrep --config=auto --config=.semgrep.yml --error --json --output=semgrep-results.json . || true
      - |
        if [ -s semgrep-results.json ]; then
          echo "Security vulnerabilities found!"
          cat semgrep-results.json
          SEVERITY=$(jq '.results[].extra.severity' semgrep-results.json | grep -c "ERROR" || true)
          if [ "$SEVERITY" -gt "0" ]; then
            echo "Critical vulnerabilities detected. Failing build."
            exit 1
          fi
        fi
      - echo "Semgrep scan completed"
```

![Semgrep Results](/images/5-Workshop/5.3-CICD/5.3.2/semgrep-results.png)

### Bước 2: Cấu hình Trivy

Trivy là máy quét bảo mật toàn diện cho containers, phát hiện lỗ hổng trong OS packages và application dependencies.

#### 2.1 Thêm Trivy vào CodeBuild

Cập nhật `buildspec.yml` để bao gồm quét Trivy:

```yaml
version: 0.2

phases:
  install:
    commands:
      - pip install semgrep
      - curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b /usr/local/bin

  pre_build:
    commands:
      # Quét Semgrep
      - echo "Running Semgrep security scan..."
      - semgrep --config=auto --error . || exit 1
      
      # Đăng nhập ECR
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $ECR_REPO_URI

  build:
    commands:
      - echo "Building Docker image..."
      - docker build -t $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION .

  post_build:
    commands:
      # Quét Trivy
      - echo "Running Trivy container scan..."
      - trivy image --exit-code 0 --severity LOW,MEDIUM --format json --output trivy-low-medium.json $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION
      - trivy image --exit-code 1 --severity HIGH,CRITICAL --format json --output trivy-high-critical.json $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION
      
      # Push image nếu quét pass
      - docker push $ECR_REPO_URI:$CODEBUILD_RESOLVED_SOURCE_VERSION

artifacts:
  files:
    - semgrep-results.json
    - trivy-low-medium.json
    - trivy-high-critical.json
```

![Trivy Scan Results](/images/5-Workshop/5.3-CICD/5.3.2/trivy-results.png)

### Bước 3: Tạo Dashboard báo cáo bảo mật

#### 3.1 Lưu trữ báo cáo trong S3

Thêm phần sau vào buildspec để lưu trữ báo cáo bảo mật:

```yaml
artifacts:
  files:
    - semgrep-results.json
    - trivy-*.json
  name: security-reports-$CODEBUILD_BUILD_NUMBER
  
reports:
  security-report:
    files:
      - semgrep-results.json
      - trivy-high-critical.json
    file-format: GENERICJSON
```

#### 3.2 Thiết lập CloudWatch Metrics

Tạo CloudWatch metrics cho các phát hiện bảo mật:

```bash
# Tạo custom metric cho security findings
aws cloudwatch put-metric-data \
    --namespace "SecurityScanning" \
    --metric-name "HighSeverityFindings" \
    --value 0 \
    --dimensions Pipeline=secure-serverless-pipeline
```

### Bước 4: Cấu hình ngưỡng thất bại

Tạo chính sách bảo mật fail builds dựa trên mức độ nghiêm trọng:

| Mức độ | Hành động |
| --- | --- |
| **CRITICAL** | Fail build ngay lập tức |
| **HIGH** | Fail build ngay lập tức |
| **MEDIUM** | Cảnh báo, cho phép build tiếp tục |
| **LOW** | Chỉ thông tin |

#### Ví dụ triển khai chính sách

```yaml
# security-policy.yml
thresholds:
  critical: 0  # Không chấp nhận critical
  high: 0      # Không chấp nhận high
  medium: 10   # Cho phép tối đa 10 medium
  low: 50      # Cho phép tối đa 50 low
  
actions:
  on_critical: block
  on_high: block
  on_medium: warn
  on_low: info
```

### Bước 5: Xác minh quét bảo mật

1. Push code với lỗ hổng cố ý (để test):

```python
# test_vulnerability.py (KHÔNG SỬ DỤNG TRONG PRODUCTION)
import os
password = "hardcoded_password_123"  # Điều này sẽ trigger Semgrep
```

2. Kiểm tra logs CodeBuild cho các phát hiện bảo mật
3. Xác minh rằng build fail do vi phạm bảo mật

![Security Scan Failure](/images/5-Workshop/5.3-CICD/5.3.2/security-scan-failure.png)

### Best Practices

{{% notice tip %}}
**Best Practices quét bảo mật:**
- Chạy quét bảo mật sớm trong pipeline (shift-left security)
- Đặt ngưỡng mức độ nghiêm trọng phù hợp với khả năng chịu rủi ro
- Cập nhật thường xuyên Semgrep rules và Trivy database
- Xem xét và giải quyết tất cả các phát hiện, kể cả mức độ thấp
- Lưu trữ báo cáo bảo mật cho compliance và auditing
{{% /notice %}}

#### Ảnh cần thiết:
- `security-scanning-flow.png` - Sơ đồ quy trình quét bảo mật
- `semgrep-results.png` - Ví dụ kết quả quét Semgrep
- `trivy-results.png` - Ví dụ kết quả quét Trivy
- `security-scan-failure.png` - Build thất bại do vấn đề bảo mật
- `security-dashboard.png` - Dashboard CloudWatch security metrics
