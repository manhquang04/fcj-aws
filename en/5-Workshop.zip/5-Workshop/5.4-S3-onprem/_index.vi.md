﻿---
title: "Xây dựng FastAPI Backend"
date: "2024-01-01"
weight: 4
chapter: false
pre: " <b> 5.4. </b> "
---

## Xây dựng FastAPI Backend

Trong phần này, bạn sẽ xây dựng FastAPI backend với kiến trúc phân lớp: API → Service → Repository, và deploy lên AWS Lambda.

![Backend Architecture](/images/5-Workshop/5.4-Backend/backend-architecture.png)

### Tổng quan kiến trúc

Ứng dụng tuân theo kiến trúc phân lớp sạch:

| Layer | Vị trí | Trách nhiệm |
| --- | --- | --- |
| **API** | `app/api/routers/` | Xử lý HTTP request, routing |
| **Service** | `app/services/` | Business logic, điều phối |
| **Repository** | `app/repositories/` | Data access, DynamoDB operations |
| **Models** | `app/models/` | Data structures, validation |
| **Core** | `app/core/` | Configuration, security, logging |

### Luồng Request

```
HTTP Request
    ↓
app/main.py (FastAPI App)
    ↓
app/api/routers/*.py (Endpoints)
    ↓
app/services/*.py (Business Logic)
    ↓
app/repositories/*.py (DynamoDB)
    ↓
DynamoDB Tables
```

### Nội dung

1. [Cấu trúc ứng dụng FastAPI](5.4.1-prepare/)
2. [DynamoDB Tables & Repository](5.4.2-create-interface-enpoint/)
3. [JWT Authentication](5.4.3-test-endpoint/)
4. [Testing API](5.4.4-dns-simulation/)

### Ứng dụng FastAPI chính

```python
# backend/app/main.py
from fastapi import FastAPI
from app.api.routers.auth import router as auth_router
from app.api.routers.products import router as products_router
from app.api.routers.orders import router as orders_router
from app.core.logging import configure_logging
from app.api.middleware import add_correlation_middleware

def create_app() -> FastAPI:
    configure_logging()
    app = FastAPI(title="Products & Orders API", version="1.0.0")
    
    add_correlation_middleware(app)
    
    @app.get("/health", tags=["health"])
    async def health() -> dict:
        return {"status": "ok"}
    
    app.include_router(auth_router, prefix="/auth", tags=["auth"])
    app.include_router(products_router, prefix="/products", tags=["products"])
    app.include_router(orders_router, prefix="/orders", tags=["orders"])
    
    return app

app = create_app()
```

### Lambda Handler với Mangum

```python
# backend/app/lambda_handler.py
from mangum import Mangum
from app.main import app

# Expose Lambda handler cho API Gateway HTTP API
handler = Mangum(app)
```

### Ví dụ Products Router

```python
# backend/app/api/routers/products.py
from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import Optional, List
from app.api.deps import require_admin, get_product_service
from app.services.product_service import ProductService
from app.models.product import ProductCreate, ProductUpdate, ProductOut

router = APIRouter()

@router.post("", response_model=ProductOut, status_code=status.HTTP_201_CREATED, 
             dependencies=[Depends(require_admin)])
async def create_product(payload: ProductCreate, 
                         service: ProductService = Depends(get_product_service)) -> ProductOut:
    return await service.create_product(payload)

@router.get("", response_model=List[ProductOut])
async def list_products(category: Optional[str] = Query(default=None), 
                        service: ProductService = Depends(get_product_service)) -> List[ProductOut]:
    return await service.list_products(category=category)

@router.get("/{product_id}", response_model=ProductOut)
async def get_product(product_id: str, 
                      service: ProductService = Depends(get_product_service)) -> ProductOut:
    product = await service.get_product(product_id)
    if not product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")
    return product

@router.put("/{product_id}", response_model=ProductOut, dependencies=[Depends(require_admin)])
async def update_product(product_id: str, payload: ProductUpdate, 
                         service: ProductService = Depends(get_product_service)) -> ProductOut:
    return await service.update_product(product_id, payload)

@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT, 
               dependencies=[Depends(require_admin)])
async def delete_product(product_id: str, 
                         service: ProductService = Depends(get_product_service)) -> None:
    await service.delete_product(product_id)
```

### DynamoDB Repository

```python
# backend/app/repositories/ddb_products.py
import boto3
import uuid
from decimal import Decimal
from typing import Optional, List
from app.models.product import ProductCreate, ProductUpdate, ProductOut
from app.utils.time import utcnow_iso

class DynamoProductsRepository:
    def __init__(self, region: str, table_name: str) -> None:
        self._table = boto3.resource("dynamodb", region_name=region).Table(table_name)

    async def create(self, payload: ProductCreate) -> ProductOut:
        product_id = str(uuid.uuid4())
        item = {
            "product_id": product_id,
            "name": payload.name,
            "price": Decimal(str(payload.price)),
            "stock": payload.stock,
            "category": payload.category or "",
            "updated_at": utcnow_iso(),
        }
        self._table.put_item(Item=item)
        return ProductOut(**item)

    async def get(self, product_id: str) -> Optional[ProductOut]:
        res = self._table.get_item(Key={"product_id": product_id})
        item = res.get("Item")
        return ProductOut(**item) if item else None

    async def list(self, category: Optional[str]) -> List[ProductOut]:
        if category:
            res = self._table.query(
                IndexName="category-index",
                KeyConditionExpression=boto3.dynamodb.conditions.Key("category").eq(category),
            )
        else:
            res = self._table.scan()
        return [ProductOut(**i) for i in res.get("Items", [])]

    async def delete(self, product_id: str) -> None:
        self._table.delete_item(Key={"product_id": product_id})
```

### Terraform Infrastructure

```hcl
# infra/modules/dynamodb/main.tf
resource "aws_dynamodb_table" "products" {
  name         = var.products_table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "product_id"

  attribute {
    name = "product_id"
    type = "S"
  }

  attribute {
    name = "category"
    type = "S"
  }

  global_secondary_index {
    name            = "category-index"
    hash_key        = "category"
    projection_type = "ALL"
  }
}

resource "aws_dynamodb_table" "orders" {
  name         = var.orders_table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "order_id"

  attribute {
    name = "order_id"
    type = "S"
  }

  attribute {
    name = "user_id"
    type = "S"
  }

  global_secondary_index {
    name            = "user-index"
    hash_key        = "user_id"
    projection_type = "ALL"
  }
}

resource "aws_dynamodb_table" "users" {
  name         = var.users_table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "user_id"

  attribute {
    name = "user_id"
    type = "S"
  }

  attribute {
    name = "email"
    type = "S"
  }

  global_secondary_index {
    name            = "email-index"
    hash_key        = "email"
    projection_type = "ALL"
  }
}
```

### API Gateway HTTP API

```hcl
# infra/modules/apigw/main.tf
resource "aws_apigatewayv2_api" "http" {
  name          = "${var.project_name}-http"
  protocol_type = "HTTP"
}

resource "aws_apigatewayv2_integration" "lambda" {
  api_id                 = aws_apigatewayv2_api.http.id
  integration_type       = "AWS_PROXY"
  integration_uri        = var.lambda_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "any" {
  api_id    = aws_apigatewayv2_api.http.id
  route_key = "$default"
  target    = "integrations/${aws_apigatewayv2_integration.lambda.id}"
}

resource "aws_apigatewayv2_stage" "default" {
  api_id      = aws_apigatewayv2_api.http.id
  name        = "$default"
  auto_deploy = true
}

resource "aws_lambda_permission" "allow_apigw" {
  statement_id  = "AllowExecutionFromAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = var.lambda_arn
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.http.execution_arn}/*/*"
}
```

{{% notice info %}}
Ứng dụng FastAPI sử dụng kiến trúc phân lớp: API layer xử lý HTTP, Service layer chứa business logic, và Repository layer quản lý data access. Sự phân tách này giúp code dễ test và bảo trì.
{{% /notice %}}

#### Ảnh cần thiết:
- `backend-architecture.png` - Kiến trúc phân lớp backend
- `dynamodb-tables.png` - DynamoDB tables trong console
- `api-endpoints.png` - FastAPI Swagger documentation
- `lambda-function.png` - Cấu hình Lambda function
