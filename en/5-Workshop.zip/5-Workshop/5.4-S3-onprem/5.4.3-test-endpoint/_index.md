﻿---
title: "Implement Cognito Authentication"
date: "2024-01-01"
weight: 3
chapter: false
pre: " <b> 5.4.3. </b> "
---

## Implement Cognito Authentication

In this section, you will set up Amazon Cognito for user authentication and integrate it with API Gateway.

![Cognito Authentication Flow](/images/5-Workshop/5.4-Backend/5.4.3/cognito-flow.png)

### Step 1: Create Cognito User Pool

```hcl
# cognito/main.tf
resource "aws_cognito_user_pool" "main" {
  name = "secure-serverless-users"
  
  # Password policy
  password_policy {
    minimum_length    = 8
    require_lowercase = true
    require_numbers   = true
    require_symbols   = true
    require_uppercase = true
  }
  
  # MFA configuration
  mfa_configuration = "OPTIONAL"
  
  software_token_mfa_configuration {
    enabled = true
  }
  
  # Account recovery
  account_recovery_setting {
    recovery_mechanism {
      name     = "verified_email"
      priority = 1
    }
  }
  
  # Email configuration
  auto_verified_attributes = ["email"]
  
  # Schema attributes
  schema {
    name                = "email"
    attribute_data_type = "String"
    required            = true
    mutable             = true
  }
  
  schema {
    name                = "name"
    attribute_data_type = "String"
    required            = true
    mutable             = true
  }
  
  # Verification message
  verification_message_template {
    default_email_option = "CONFIRM_WITH_CODE"
    email_subject        = "Your verification code"
    email_message        = "Your verification code is {####}"
  }
  
  tags = {
    Environment = var.environment
    Project     = "secure-serverless"
  }
}
```

### Step 2: Create via AWS Console

1. Navigate to **Cognito Console** → **Create user pool**
2. Configure sign-in experience:
   - **Sign-in options**: Email
   - **User name requirements**: As needed

![Create User Pool](/images/5-Workshop/5.4-Backend/5.4.3/create-user-pool.png)

3. Configure security requirements:
   - **Password policy**: Custom (8 chars, mixed case, numbers, symbols)
   - **MFA**: Optional

4. Configure sign-up experience:
   - **Self-registration**: Enabled
   - **Required attributes**: email, name

### Step 3: Create App Client

```hcl
resource "aws_cognito_user_pool_client" "main" {
  name         = "secure-serverless-client"
  user_pool_id = aws_cognito_user_pool.main.id
  
  # Auth flows
  explicit_auth_flows = [
    "ALLOW_USER_PASSWORD_AUTH",
    "ALLOW_REFRESH_TOKEN_AUTH",
    "ALLOW_USER_SRP_AUTH"
  ]
  
  # Token validity
  access_token_validity  = 1   # hours
  id_token_validity      = 1   # hours
  refresh_token_validity = 30  # days
  
  token_validity_units {
    access_token  = "hours"
    id_token      = "hours"
    refresh_token = "days"
  }
  
  # OAuth settings
  allowed_oauth_flows          = ["code", "implicit"]
  allowed_oauth_scopes         = ["email", "openid", "profile"]
  supported_identity_providers = ["COGNITO"]
  
  callback_urls = [
    "https://your-app.com/callback",
    "http://localhost:3000/callback"  # For development
  ]
  
  logout_urls = [
    "https://your-app.com/logout",
    "http://localhost:3000/logout"
  ]
  
  # Prevent user existence errors
  prevent_user_existence_errors = "ENABLED"
  
  # Generate client secret
  generate_secret = false  # Set to true for server-side apps
}
```

![App Client Settings](/images/5-Workshop/5.4-Backend/5.4.3/app-client.png)

### Step 4: Create Domain

```hcl
resource "aws_cognito_user_pool_domain" "main" {
  domain       = "secure-serverless-${random_string.suffix.result}"
  user_pool_id = aws_cognito_user_pool.main.id
}

resource "random_string" "suffix" {
  length  = 8
  special = false
  upper   = false
}
```

### Step 5: Configure API Gateway Authorizer

```hcl
resource "aws_api_gateway_authorizer" "cognito" {
  name          = "cognito-authorizer"
  rest_api_id   = aws_api_gateway_rest_api.main.id
  type          = "COGNITO_USER_POOLS"
  provider_arns = [aws_cognito_user_pool.main.arn]
  
  identity_source = "method.request.header.Authorization"
}

# Update API method to use authorizer
resource "aws_api_gateway_method" "protected" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  resource_id   = aws_api_gateway_resource.items.id
  http_method   = "GET"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}
```

### Step 6: Test Authentication

#### 6.1 Create Test User

```bash
# Create user
aws cognito-idp admin-create-user \
    --user-pool-id YOUR_USER_POOL_ID \
    --username testuser@example.com \
    --user-attributes Name=email,Value=testuser@example.com Name=name,Value="Test User" \
    --temporary-password "TempPass123!"

# Set permanent password
aws cognito-idp admin-set-user-password \
    --user-pool-id YOUR_USER_POOL_ID \
    --username testuser@example.com \
    --password "SecurePass123!" \
    --permanent
```

#### 6.2 Authenticate and Get Token

```bash
# Initiate auth
aws cognito-idp initiate-auth \
    --client-id YOUR_CLIENT_ID \
    --auth-flow USER_PASSWORD_AUTH \
    --auth-parameters USERNAME=testuser@example.com,PASSWORD=SecurePass123!
```

The response will include:
- `IdToken`: JWT for API authentication
- `AccessToken`: JWT for user information
- `RefreshToken`: For obtaining new tokens

#### 6.3 Call Protected API

```bash
# Use the IdToken to call the API
curl -X GET https://your-api-id.execute-api.ap-southeast-1.amazonaws.com/prod/items \
    -H "Authorization: Bearer YOUR_ID_TOKEN"
```

![API Auth Test](/images/5-Workshop/5.4-Backend/5.4.3/api-auth-test.png)

### Step 7: Lambda Token Verification

```python
import boto3
from jose import jwt, JWTError
import requests
import os

def verify_token(token):
    """Verify Cognito JWT token"""
    region = os.environ['AWS_REGION']
    user_pool_id = os.environ['USER_POOL_ID']
    client_id = os.environ['CLIENT_ID']
    
    # Get JWKS
    jwks_url = f'https://cognito-idp.{region}.amazonaws.com/{user_pool_id}/.well-known/jwks.json'
    jwks = requests.get(jwks_url).json()
    
    try:
        # Decode and verify token
        claims = jwt.decode(
            token,
            jwks,
            algorithms=['RS256'],
            audience=client_id,
            issuer=f'https://cognito-idp.{region}.amazonaws.com/{user_pool_id}'
        )
        return claims
    except JWTError as e:
        raise Exception(f'Token verification failed: {str(e)}')
```

{{% notice warning %}}
Never expose your User Pool ID or Client ID in client-side code without proper security measures. Use environment variables and secrets management.
{{% /notice %}}

#### Images Required:
- `cognito-flow.png` - Cognito authentication flow diagram
- `create-user-pool.png` - User Pool creation in console
- `app-client.png` - App client configuration
- `api-auth-test.png` - Testing authenticated API calls
