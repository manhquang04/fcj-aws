﻿---
title: "Triển khai xác thực Cognito"
date: "2024-01-01"
weight: 3
chapter: false
pre: " <b> 5.4.3. </b> "
---

## Triển khai xác thực Cognito

Trong phần này, bạn sẽ thiết lập Amazon Cognito cho xác thực người dùng và tích hợp với API Gateway.

![Cognito Authentication Flow](/images/5-Workshop/5.4-Backend/5.4.3/cognito-flow.png)

### Bước 1: Tạo Cognito User Pool

```hcl
# cognito/main.tf
resource "aws_cognito_user_pool" "main" {
  name = "secure-serverless-users"
  
  # Chính sách mật khẩu
  password_policy {
    minimum_length    = 8
    require_lowercase = true
    require_numbers   = true
    require_symbols   = true
    require_uppercase = true
  }
  
  # Cấu hình MFA
  mfa_configuration = "OPTIONAL"
  
  software_token_mfa_configuration {
    enabled = true
  }
  
  # Khôi phục tài khoản
  account_recovery_setting {
    recovery_mechanism {
      name     = "verified_email"
      priority = 1
    }
  }
  
  # Cấu hình email
  auto_verified_attributes = ["email"]
  
  # Schema attributes
  schema {
    name                = "email"
    attribute_data_type = "String"
    required            = true
    mutable             = true
  }
  
  schema {
    name                = "name"
    attribute_data_type = "String"
    required            = true
    mutable             = true
  }
  
  # Tin nhắn xác minh
  verification_message_template {
    default_email_option = "CONFIRM_WITH_CODE"
    email_subject        = "Mã xác minh của bạn"
    email_message        = "Mã xác minh của bạn là {####}"
  }
  
  tags = {
    Environment = var.environment
    Project     = "secure-serverless"
  }
}
```

### Bước 2: Tạo qua AWS Console

1. Điều hướng đến **Cognito Console** → **Create user pool**
2. Cấu hình trải nghiệm đăng nhập:
   - **Sign-in options**: Email
   - **User name requirements**: Theo nhu cầu

![Create User Pool](/images/5-Workshop/5.4-Backend/5.4.3/create-user-pool.png)

3. Cấu hình yêu cầu bảo mật:
   - **Password policy**: Custom (8 ký tự, chữ hoa/thường, số, ký hiệu)
   - **MFA**: Optional

4. Cấu hình trải nghiệm đăng ký:
   - **Self-registration**: Enabled
   - **Required attributes**: email, name

### Bước 3: Tạo App Client

```hcl
resource "aws_cognito_user_pool_client" "main" {
  name         = "secure-serverless-client"
  user_pool_id = aws_cognito_user_pool.main.id
  
  # Auth flows
  explicit_auth_flows = [
    "ALLOW_USER_PASSWORD_AUTH",
    "ALLOW_REFRESH_TOKEN_AUTH",
    "ALLOW_USER_SRP_AUTH"
  ]
  
  # Token validity
  access_token_validity  = 1   # giờ
  id_token_validity      = 1   # giờ
  refresh_token_validity = 30  # ngày
  
  token_validity_units {
    access_token  = "hours"
    id_token      = "hours"
    refresh_token = "days"
  }
  
  # OAuth settings
  allowed_oauth_flows          = ["code", "implicit"]
  allowed_oauth_scopes         = ["email", "openid", "profile"]
  supported_identity_providers = ["COGNITO"]
  
  callback_urls = [
    "https://your-app.com/callback",
    "http://localhost:3000/callback"  # Cho development
  ]
  
  logout_urls = [
    "https://your-app.com/logout",
    "http://localhost:3000/logout"
  ]
  
  # Ngăn lỗi user existence
  prevent_user_existence_errors = "ENABLED"
  
  # Tạo client secret
  generate_secret = false  # Đặt true cho server-side apps
}
```

![App Client Settings](/images/5-Workshop/5.4-Backend/5.4.3/app-client.png)

### Bước 4: Tạo Domain

```hcl
resource "aws_cognito_user_pool_domain" "main" {
  domain       = "secure-serverless-${random_string.suffix.result}"
  user_pool_id = aws_cognito_user_pool.main.id
}

resource "random_string" "suffix" {
  length  = 8
  special = false
  upper   = false
}
```

### Bước 5: Cấu hình API Gateway Authorizer

```hcl
resource "aws_api_gateway_authorizer" "cognito" {
  name          = "cognito-authorizer"
  rest_api_id   = aws_api_gateway_rest_api.main.id
  type          = "COGNITO_USER_POOLS"
  provider_arns = [aws_cognito_user_pool.main.arn]
  
  identity_source = "method.request.header.Authorization"
}

# Cập nhật API method để sử dụng authorizer
resource "aws_api_gateway_method" "protected" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  resource_id   = aws_api_gateway_resource.items.id
  http_method   = "GET"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}
```

### Bước 6: Test xác thực

#### 6.1 Tạo User test

```bash
# Tạo user
aws cognito-idp admin-create-user \
    --user-pool-id YOUR_USER_POOL_ID \
    --username testuser@example.com \
    --user-attributes Name=email,Value=testuser@example.com Name=name,Value="Test User" \
    --temporary-password "TempPass123!"

# Đặt mật khẩu vĩnh viễn
aws cognito-idp admin-set-user-password \
    --user-pool-id YOUR_USER_POOL_ID \
    --username testuser@example.com \
    --password "SecurePass123!" \
    --permanent
```

#### 6.2 Xác thực và lấy Token

```bash
# Khởi tạo auth
aws cognito-idp initiate-auth \
    --client-id YOUR_CLIENT_ID \
    --auth-flow USER_PASSWORD_AUTH \
    --auth-parameters USERNAME=testuser@example.com,PASSWORD=SecurePass123!
```

Response sẽ bao gồm:
- `IdToken`: JWT cho xác thực API
- `AccessToken`: JWT cho thông tin user
- `RefreshToken`: Để lấy tokens mới

#### 6.3 Gọi Protected API

```bash
# Sử dụng IdToken để gọi API
curl -X GET https://your-api-id.execute-api.ap-southeast-1.amazonaws.com/prod/items \
    -H "Authorization: Bearer YOUR_ID_TOKEN"
```

![API Auth Test](/images/5-Workshop/5.4-Backend/5.4.3/api-auth-test.png)

### Bước 7: Xác minh Token trong Lambda

```python
import boto3
from jose import jwt, JWTError
import requests
import os

def verify_token(token):
    """Xác minh Cognito JWT token"""
    region = os.environ['AWS_REGION']
    user_pool_id = os.environ['USER_POOL_ID']
    client_id = os.environ['CLIENT_ID']
    
    # Lấy JWKS
    jwks_url = f'https://cognito-idp.{region}.amazonaws.com/{user_pool_id}/.well-known/jwks.json'
    jwks = requests.get(jwks_url).json()
    
    try:
        # Decode và xác minh token
        claims = jwt.decode(
            token,
            jwks,
            algorithms=['RS256'],
            audience=client_id,
            issuer=f'https://cognito-idp.{region}.amazonaws.com/{user_pool_id}'
        )
        return claims
    except JWTError as e:
        raise Exception(f'Xác minh token thất bại: {str(e)}')
```

{{% notice warning %}}
Không bao giờ expose User Pool ID hoặc Client ID trong client-side code mà không có biện pháp bảo mật phù hợp. Sử dụng environment variables và secrets management.
{{% /notice %}}

#### Ảnh cần thiết:
- `cognito-flow.png` - Sơ đồ luồng xác thực Cognito
- `create-user-pool.png` - Tạo User Pool trong console
- `app-client.png` - Cấu hình App client
- `api-auth-test.png` - Test các API calls đã xác thực
