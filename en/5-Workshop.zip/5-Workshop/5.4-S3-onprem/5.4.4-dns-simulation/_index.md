﻿---
title: "Test and Validate Backend"
date: "2024-01-01"
weight: 4
chapter: false
pre: " <b> 5.4.4. </b> "
---

## Test and Validate Backend

In this section, you will perform comprehensive testing of the serverless backend to ensure all components work correctly together.

### Step 1: End-to-End Test Plan

| Test Case | Description | Expected Result |
| --- | --- | --- |
| Create Item | POST request to create new item | 201 Created |
| Get Items | GET request to retrieve items | 200 OK with items |
| Update Item | PUT request to update item | 200 OK |
| Delete Item | DELETE request to remove item | 204 No Content |
| Unauthorized Access | Request without token | 401 Unauthorized |
| Invalid Token | Request with invalid token | 403 Forbidden |

### Step 2: Set Up Test Environment

```bash
# Set environment variables
export API_URL="https://YOUR_API_ID.execute-api.ap-southeast-1.amazonaws.com/prod"
export USER_POOL_ID="ap-southeast-1_XXXXXXXXX"
export CLIENT_ID="your-client-id"

# Get authentication token
TOKEN=$(aws cognito-idp initiate-auth \
    --client-id $CLIENT_ID \
    --auth-flow USER_PASSWORD_AUTH \
    --auth-parameters USERNAME=testuser@example.com,PASSWORD=SecurePass123! \
    --query 'AuthenticationResult.IdToken' \
    --output text)

echo "Token: $TOKEN"
```

### Step 3: API Testing with curl

#### 3.1 Create Item

```bash
curl -X POST $API_URL/items \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "name": "Test Item",
        "description": "This is a test item",
        "price": 29.99
    }'
```

Expected response:
```json
{
    "message": "Item created successfully",
    "item": {
        "PK": "USER#user-id",
        "SK": "ITEM#2024-01-15T10:30:00Z",
        "name": "Test Item",
        "description": "This is a test item",
        "price": 29.99
    }
}
```

#### 3.2 Get All Items

```bash
curl -X GET $API_URL/items \
    -H "Authorization: Bearer $TOKEN"
```

#### 3.3 Get Single Item

```bash
curl -X GET "$API_URL/items/ITEM%232024-01-15T10:30:00Z" \
    -H "Authorization: Bearer $TOKEN"
```

#### 3.4 Update Item

```bash
curl -X PUT "$API_URL/items/ITEM%232024-01-15T10:30:00Z" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "name": "Updated Item",
        "price": 39.99
    }'
```

#### 3.5 Delete Item

```bash
curl -X DELETE "$API_URL/items/ITEM%232024-01-15T10:30:00Z" \
    -H "Authorization: Bearer $TOKEN"
```

![API Test Results](/images/5-Workshop/5.4-Backend/5.4.4/api-test-results.png)

### Step 4: Test Authentication Scenarios

#### 4.1 Test Unauthorized Access

```bash
# Request without token
curl -X GET $API_URL/items

# Expected: 401 Unauthorized
```

#### 4.2 Test Invalid Token

```bash
# Request with invalid token
curl -X GET $API_URL/items \
    -H "Authorization: Bearer invalid-token"

# Expected: 401 Unauthorized
```

#### 4.3 Test Expired Token

```bash
# Wait for token to expire (1 hour), then test
curl -X GET $API_URL/items \
    -H "Authorization: Bearer $EXPIRED_TOKEN"

# Expected: 401 Unauthorized with message about expired token
```

### Step 5: Load Testing with Artillery

Create `load-test.yml`:

```yaml
config:
  target: "https://YOUR_API_ID.execute-api.ap-southeast-1.amazonaws.com/prod"
  phases:
    - duration: 60
      arrivalRate: 10
      name: "Warm up"
    - duration: 120
      arrivalRate: 50
      name: "Ramp up"
    - duration: 60
      arrivalRate: 10
      name: "Cool down"
  defaults:
    headers:
      Authorization: "Bearer {{ $processEnvironment.TOKEN }}"
      Content-Type: "application/json"

scenarios:
  - name: "Get items"
    weight: 70
    flow:
      - get:
          url: "/items"
          
  - name: "Create and delete item"
    weight: 30
    flow:
      - post:
          url: "/items"
          json:
            name: "Load test item"
            description: "Created during load test"
```

Run load test:

```bash
export TOKEN="your-token"
artillery run load-test.yml
```

![Load Test Results](/images/5-Workshop/5.4-Backend/5.4.4/load-test.png)

### Step 6: Verify CloudWatch Logs

Check Lambda logs for errors:

```bash
# Get recent logs
aws logs filter-log-events \
    --log-group-name /aws/lambda/secure-serverless-api \
    --start-time $(date -d '1 hour ago' +%s000) \
    --filter-pattern "ERROR"
```

![CloudWatch Logs](/images/5-Workshop/5.4-Backend/5.4.4/cloudwatch-logs.png)

### Step 7: Verify DynamoDB Data

```bash
# Scan table to verify data
aws dynamodb scan \
    --table-name secure-serverless-table \
    --max-items 10
```

### Step 8: Create Automated Test Script

```python
#!/usr/bin/env python3
"""
Backend validation test script
"""
import requests
import json
import boto3
import sys

API_URL = "https://YOUR_API_ID.execute-api.ap-southeast-1.amazonaws.com/prod"

def get_token():
    """Get Cognito authentication token"""
    client = boto3.client('cognito-idp')
    response = client.initiate_auth(
        ClientId='your-client-id',
        AuthFlow='USER_PASSWORD_AUTH',
        AuthParameters={
            'USERNAME': 'testuser@example.com',
            'PASSWORD': 'SecurePass123!'
        }
    )
    return response['AuthenticationResult']['IdToken']

def test_create_item(token):
    """Test item creation"""
    response = requests.post(
        f"{API_URL}/items",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "Test", "price": 10}
    )
    assert response.status_code == 201, f"Create failed: {response.text}"
    print("✅ Create item: PASSED")
    return response.json()

def test_get_items(token):
    """Test getting items"""
    response = requests.get(
        f"{API_URL}/items",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200, f"Get failed: {response.text}"
    print("✅ Get items: PASSED")
    return response.json()

def test_unauthorized():
    """Test unauthorized access"""
    response = requests.get(f"{API_URL}/items")
    assert response.status_code == 401, "Should be unauthorized"
    print("✅ Unauthorized access: PASSED")

def run_tests():
    """Run all tests"""
    print("Starting backend validation tests...\n")
    
    token = get_token()
    print("✅ Authentication: PASSED\n")
    
    test_unauthorized()
    test_create_item(token)
    test_get_items(token)
    
    print("\n🎉 All tests passed!")

if __name__ == "__main__":
    run_tests()
```

Run the test:

```bash
python test_backend.py
```

![Test Results](/images/5-Workshop/5.4-Backend/5.4.4/test-results.png)

{{% notice tip %}}
Always run comprehensive tests before deploying to production. Include positive tests (expected behavior), negative tests (error handling), and load tests (performance).
{{% /notice %}}

#### Images Required:
- `api-test-results.png` - curl command results
- `load-test.png` - Artillery load test results
- `cloudwatch-logs.png` - CloudWatch logs view
- `test-results.png` - Automated test script output
