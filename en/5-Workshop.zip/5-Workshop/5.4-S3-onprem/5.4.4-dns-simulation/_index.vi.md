﻿---
title: "Test và xác thực Backend"
date: "2024-01-01"
weight: 4
chapter: false
pre: " <b> 5.4.4. </b> "
---

## Test và xác thực Backend

Trong phần này, bạn sẽ thực hiện kiểm thử toàn diện backend serverless để đảm bảo tất cả các thành phần hoạt động chính xác cùng nhau.

### Bước 1: Kế hoạch Test End-to-End

| Test Case | Mô tả | Kết quả mong đợi |
| --- | --- | --- |
| Create Item | POST request để tạo item mới | 201 Created |
| Get Items | GET request để lấy items | 200 OK với items |
| Update Item | PUT request để cập nhật item | 200 OK |
| Delete Item | DELETE request để xóa item | 204 No Content |
| Unauthorized Access | Request không có token | 401 Unauthorized |
| Invalid Token | Request với token không hợp lệ | 403 Forbidden |

### Bước 2: Thiết lập môi trường Test

```bash
# Đặt environment variables
export API_URL="https://YOUR_API_ID.execute-api.ap-southeast-1.amazonaws.com/prod"
export USER_POOL_ID="ap-southeast-1_XXXXXXXXX"
export CLIENT_ID="your-client-id"

# Lấy authentication token
TOKEN=$(aws cognito-idp initiate-auth \
    --client-id $CLIENT_ID \
    --auth-flow USER_PASSWORD_AUTH \
    --auth-parameters USERNAME=testuser@example.com,PASSWORD=SecurePass123! \
    --query 'AuthenticationResult.IdToken' \
    --output text)

echo "Token: $TOKEN"
```

### Bước 3: Test API với curl

#### 3.1 Tạo Item

```bash
curl -X POST $API_URL/items \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "name": "Test Item",
        "description": "This is a test item",
        "price": 29.99
    }'
```

Response mong đợi:
```json
{
    "message": "Item created successfully",
    "item": {
        "PK": "USER#user-id",
        "SK": "ITEM#2024-01-15T10:30:00Z",
        "name": "Test Item",
        "description": "This is a test item",
        "price": 29.99
    }
}
```

#### 3.2 Lấy tất cả Items

```bash
curl -X GET $API_URL/items \
    -H "Authorization: Bearer $TOKEN"
```

#### 3.3 Lấy một Item

```bash
curl -X GET "$API_URL/items/ITEM%232024-01-15T10:30:00Z" \
    -H "Authorization: Bearer $TOKEN"
```

#### 3.4 Cập nhật Item

```bash
curl -X PUT "$API_URL/items/ITEM%232024-01-15T10:30:00Z" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "name": "Updated Item",
        "price": 39.99
    }'
```

#### 3.5 Xóa Item

```bash
curl -X DELETE "$API_URL/items/ITEM%232024-01-15T10:30:00Z" \
    -H "Authorization: Bearer $TOKEN"
```

![API Test Results](/images/5-Workshop/5.4-Backend/5.4.4/api-test-results.png)

### Bước 4: Test các kịch bản xác thực

#### 4.1 Test truy cập không xác thực

```bash
# Request không có token
curl -X GET $API_URL/items

# Mong đợi: 401 Unauthorized
```

#### 4.2 Test Token không hợp lệ

```bash
# Request với token không hợp lệ
curl -X GET $API_URL/items \
    -H "Authorization: Bearer invalid-token"

# Mong đợi: 401 Unauthorized
```

#### 4.3 Test Token hết hạn

```bash
# Đợi token hết hạn (1 giờ), sau đó test
curl -X GET $API_URL/items \
    -H "Authorization: Bearer $EXPIRED_TOKEN"

# Mong đợi: 401 Unauthorized với thông báo token hết hạn
```

### Bước 5: Load Testing với Artillery

Tạo `load-test.yml`:

```yaml
config:
  target: "https://YOUR_API_ID.execute-api.ap-southeast-1.amazonaws.com/prod"
  phases:
    - duration: 60
      arrivalRate: 10
      name: "Warm up"
    - duration: 120
      arrivalRate: 50
      name: "Ramp up"
    - duration: 60
      arrivalRate: 10
      name: "Cool down"
  defaults:
    headers:
      Authorization: "Bearer {{ $processEnvironment.TOKEN }}"
      Content-Type: "application/json"

scenarios:
  - name: "Get items"
    weight: 70
    flow:
      - get:
          url: "/items"
          
  - name: "Create and delete item"
    weight: 30
    flow:
      - post:
          url: "/items"
          json:
            name: "Load test item"
            description: "Created during load test"
```

Chạy load test:

```bash
export TOKEN="your-token"
artillery run load-test.yml
```

![Load Test Results](/images/5-Workshop/5.4-Backend/5.4.4/load-test.png)

### Bước 6: Xác minh CloudWatch Logs

Kiểm tra Lambda logs cho errors:

```bash
# Lấy logs gần đây
aws logs filter-log-events \
    --log-group-name /aws/lambda/secure-serverless-api \
    --start-time $(date -d '1 hour ago' +%s000) \
    --filter-pattern "ERROR"
```

![CloudWatch Logs](/images/5-Workshop/5.4-Backend/5.4.4/cloudwatch-logs.png)

### Bước 7: Xác minh dữ liệu DynamoDB

```bash
# Scan table để xác minh dữ liệu
aws dynamodb scan \
    --table-name secure-serverless-table \
    --max-items 10
```

### Bước 8: Tạo Script Test tự động

```python
#!/usr/bin/env python3
"""
Script test xác thực backend
"""
import requests
import json
import boto3
import sys

API_URL = "https://YOUR_API_ID.execute-api.ap-southeast-1.amazonaws.com/prod"

def get_token():
    """Lấy Cognito authentication token"""
    client = boto3.client('cognito-idp')
    response = client.initiate_auth(
        ClientId='your-client-id',
        AuthFlow='USER_PASSWORD_AUTH',
        AuthParameters={
            'USERNAME': 'testuser@example.com',
            'PASSWORD': 'SecurePass123!'
        }
    )
    return response['AuthenticationResult']['IdToken']

def test_create_item(token):
    """Test tạo item"""
    response = requests.post(
        f"{API_URL}/items",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": "Test", "price": 10}
    )
    assert response.status_code == 201, f"Create failed: {response.text}"
    print("✅ Create item: PASSED")
    return response.json()

def test_get_items(token):
    """Test lấy items"""
    response = requests.get(
        f"{API_URL}/items",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200, f"Get failed: {response.text}"
    print("✅ Get items: PASSED")
    return response.json()

def test_unauthorized():
    """Test truy cập không xác thực"""
    response = requests.get(f"{API_URL}/items")
    assert response.status_code == 401, "Should be unauthorized"
    print("✅ Unauthorized access: PASSED")

def run_tests():
    """Chạy tất cả tests"""
    print("Starting backend validation tests...\n")
    
    token = get_token()
    print("✅ Authentication: PASSED\n")
    
    test_unauthorized()
    test_create_item(token)
    test_get_items(token)
    
    print("\n🎉 Tất cả tests passed!")

if __name__ == "__main__":
    run_tests()
```

Chạy test:

```bash
python test_backend.py
```

![Test Results](/images/5-Workshop/5.4-Backend/5.4.4/test-results.png)

{{% notice tip %}}
Luôn chạy kiểm thử toàn diện trước khi triển khai production. Bao gồm positive tests (hành vi mong đợi), negative tests (xử lý lỗi), và load tests (hiệu suất).
{{% /notice %}}

#### Ảnh cần thiết:
- `api-test-results.png` - Kết quả lệnh curl
- `load-test.png` - Kết quả load test Artillery
- `cloudwatch-logs.png` - Giao diện CloudWatch logs
- `test-results.png` - Output script test tự động
