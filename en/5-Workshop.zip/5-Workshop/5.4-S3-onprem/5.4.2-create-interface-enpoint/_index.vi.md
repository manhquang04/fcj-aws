﻿---
title: "Cấu hình DynamoDB"
date: "2024-01-01"
weight: 2
chapter: false
pre: " <b> 5.4.2. </b> "
---

## Cấu hình DynamoDB

Trong phần này, bạn sẽ tạo và cấu hình bảng DynamoDB để lưu trữ dữ liệu ứng dụng.

### Bước 1: Thiết kế Schema bảng

Cho ứng dụng serverless, chúng ta sẽ tạo bảng với thiết kế sau:

| Thuộc tính | Loại | Loại Key |
| --- | --- | --- |
| `PK` | String | Partition Key |
| `SK` | String | Sort Key |
| `data` | Map | - |
| `createdAt` | String | - |
| `updatedAt` | String | - |

![DynamoDB Table Design](/images/5-Workshop/5.4-Backend/5.4.2/dynamodb-design.png)

### Bước 2: Tạo bảng DynamoDB với Terraform

```hcl
# dynamodb/main.tf
resource "aws_dynamodb_table" "main" {
  name           = "secure-serverless-table"
  billing_mode   = "PAY_PER_REQUEST"  # On-demand capacity
  hash_key       = "PK"
  range_key      = "SK"
  
  attribute {
    name = "PK"
    type = "S"
  }
  
  attribute {
    name = "SK"
    type = "S"
  }
  
  attribute {
    name = "GSI1PK"
    type = "S"
  }
  
  attribute {
    name = "GSI1SK"
    type = "S"
  }
  
  # Global Secondary Index
  global_secondary_index {
    name            = "GSI1"
    hash_key        = "GSI1PK"
    range_key       = "GSI1SK"
    projection_type = "ALL"
  }
  
  # Bật Point-in-Time Recovery
  point_in_time_recovery {
    enabled = true
  }
  
  # Bật server-side encryption với KMS
  server_side_encryption {
    enabled     = true
    kms_key_arn = var.kms_key_arn
  }
  
  # Bật TTL cho tự động xóa item
  ttl {
    attribute_name = "expiresAt"
    enabled        = true
  }
  
  tags = {
    Environment = var.environment
    Project     = "secure-serverless"
  }
}
```

### Bước 3: Tạo qua AWS Console

1. Điều hướng đến **DynamoDB Console** → **Create table**
2. Cấu hình:
   - **Table name**: `secure-serverless-table`
   - **Partition key**: `PK` (String)
   - **Sort key**: `SK` (String)
   - **Table settings**: Customize settings

![Create DynamoDB Table](/images/5-Workshop/5.4-Backend/5.4.2/create-table.png)

3. Cấu hình capacity:
   - Chọn **On-demand** cho tự động scaling

4. Bật mã hóa:
   - Chọn **AWS managed key** hoặc custom KMS key của bạn

### Bước 4: Tạo Global Secondary Index

```hcl
# Thêm GSI cho các access patterns khác nhau
global_secondary_index {
  name            = "GSI1"
  hash_key        = "GSI1PK"
  range_key       = "GSI1SK"
  projection_type = "ALL"
}
```

![GSI Configuration](/images/5-Workshop/5.4-Backend/5.4.2/gsi-config.png)

### Bước 5: Cấu hình Auto Scaling (Tùy chọn)

Nếu sử dụng provisioned capacity:

```hcl
resource "aws_appautoscaling_target" "read_target" {
  max_capacity       = 100
  min_capacity       = 5
  resource_id        = "table/${aws_dynamodb_table.main.name}"
  scalable_dimension = "dynamodb:table:ReadCapacityUnits"
  service_namespace  = "dynamodb"
}

resource "aws_appautoscaling_policy" "read_policy" {
  name               = "DynamoDBReadAutoScaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.read_target.resource_id
  scalable_dimension = aws_appautoscaling_target.read_target.scalable_dimension
  service_namespace  = aws_appautoscaling_target.read_target.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "DynamoDBReadCapacityUtilization"
    }
    target_value = 70
  }
}
```

### Bước 6: Tích hợp Lambda

Cập nhật Lambda function để tương tác với DynamoDB:

```python
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def create_item(user_id, item_data):
    """Tạo item mới trong DynamoDB"""
    timestamp = datetime.utcnow().isoformat()
    
    item = {
        'PK': f'USER#{user_id}',
        'SK': f'ITEM#{timestamp}',
        'GSI1PK': 'ITEM',
        'GSI1SK': timestamp,
        'data': item_data,
        'createdAt': timestamp,
        'updatedAt': timestamp
    }
    
    table.put_item(Item=item)
    return item

def get_user_items(user_id):
    """Lấy tất cả items của user"""
    response = table.query(
        KeyConditionExpression='PK = :pk AND begins_with(SK, :sk)',
        ExpressionAttributeValues={
            ':pk': f'USER#{user_id}',
            ':sk': 'ITEM#'
        }
    )
    return response['Items']

def get_all_items():
    """Lấy tất cả items sử dụng GSI"""
    response = table.query(
        IndexName='GSI1',
        KeyConditionExpression='GSI1PK = :pk',
        ExpressionAttributeValues={
            ':pk': 'ITEM'
        },
        ScanIndexForward=False  # Mới nhất trước
    )
    return response['Items']
```

### Bước 7: Xác minh tạo bảng

```bash
# Liệt kê các bảng
aws dynamodb list-tables

# Mô tả bảng
aws dynamodb describe-table --table-name secure-serverless-table

# Test put item
aws dynamodb put-item \
    --table-name secure-serverless-table \
    --item '{"PK": {"S": "USER#test"}, "SK": {"S": "ITEM#001"}, "data": {"S": "test data"}}'

# Query items
aws dynamodb query \
    --table-name secure-serverless-table \
    --key-condition-expression "PK = :pk" \
    --expression-attribute-values '{":pk": {"S": "USER#test"}}'
```

![DynamoDB Items](/images/5-Workshop/5.4-Backend/5.4.2/dynamodb-items.png)

{{% notice tip %}}
Sử dụng single-table design patterns trong DynamoDB để có hiệu suất và chi phí tốt hơn. Thiết kế access patterns trước, sau đó tạo schema bảng.
{{% /notice %}}

#### Ảnh cần thiết:
- `dynamodb-design.png` - Sơ đồ thiết kế schema bảng
- `create-table.png` - Console tạo bảng DynamoDB
- `gsi-config.png` - Cấu hình Global Secondary Index
- `dynamodb-items.png` - Items trong bảng DynamoDB
