﻿---
title: "Configure DynamoDB"
date: "2024-01-01"
weight: 2
chapter: false
pre: " <b> 5.4.2. </b> "
---

## Configure DynamoDB

In this section, you will create and configure a DynamoDB table for storing application data.

### Step 1: Design Table Schema

For our serverless application, we'll create a table with the following design:

| Attribute | Type | Key Type |
| --- | --- | --- |
| `PK` | String | Partition Key |
| `SK` | String | Sort Key |
| `data` | Map | - |
| `createdAt` | String | - |
| `updatedAt` | String | - |

![DynamoDB Table Design](/images/5-Workshop/5.4-Backend/5.4.2/dynamodb-design.png)

### Step 2: Create DynamoDB Table with Terraform

```hcl
# dynamodb/main.tf
resource "aws_dynamodb_table" "main" {
  name           = "secure-serverless-table"
  billing_mode   = "PAY_PER_REQUEST"  # On-demand capacity
  hash_key       = "PK"
  range_key      = "SK"
  
  attribute {
    name = "PK"
    type = "S"
  }
  
  attribute {
    name = "SK"
    type = "S"
  }
  
  attribute {
    name = "GSI1PK"
    type = "S"
  }
  
  attribute {
    name = "GSI1SK"
    type = "S"
  }
  
  # Global Secondary Index
  global_secondary_index {
    name            = "GSI1"
    hash_key        = "GSI1PK"
    range_key       = "GSI1SK"
    projection_type = "ALL"
  }
  
  # Enable Point-in-Time Recovery
  point_in_time_recovery {
    enabled = true
  }
  
  # Enable server-side encryption with KMS
  server_side_encryption {
    enabled     = true
    kms_key_arn = var.kms_key_arn
  }
  
  # Enable TTL for automatic item expiration
  ttl {
    attribute_name = "expiresAt"
    enabled        = true
  }
  
  tags = {
    Environment = var.environment
    Project     = "secure-serverless"
  }
}
```

### Step 3: Create via AWS Console

1. Navigate to **DynamoDB Console** → **Create table**
2. Configure:
   - **Table name**: `secure-serverless-table`
   - **Partition key**: `PK` (String)
   - **Sort key**: `SK` (String)
   - **Table settings**: Customize settings

![Create DynamoDB Table](/images/5-Workshop/5.4-Backend/5.4.2/create-table.png)

3. Configure capacity:
   - Select **On-demand** for automatic scaling

4. Enable encryption:
   - Select **AWS managed key** or your custom KMS key

### Step 4: Create Global Secondary Index

```hcl
# Add GSI for querying by different access patterns
global_secondary_index {
  name            = "GSI1"
  hash_key        = "GSI1PK"
  range_key       = "GSI1SK"
  projection_type = "ALL"
}
```

![GSI Configuration](/images/5-Workshop/5.4-Backend/5.4.2/gsi-config.png)

### Step 5: Configure Auto Scaling (Optional)

If using provisioned capacity:

```hcl
resource "aws_appautoscaling_target" "read_target" {
  max_capacity       = 100
  min_capacity       = 5
  resource_id        = "table/${aws_dynamodb_table.main.name}"
  scalable_dimension = "dynamodb:table:ReadCapacityUnits"
  service_namespace  = "dynamodb"
}

resource "aws_appautoscaling_policy" "read_policy" {
  name               = "DynamoDBReadAutoScaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.read_target.resource_id
  scalable_dimension = aws_appautoscaling_target.read_target.scalable_dimension
  service_namespace  = aws_appautoscaling_target.read_target.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "DynamoDBReadCapacityUtilization"
    }
    target_value = 70
  }
}
```

### Step 6: Lambda Integration

Update your Lambda function to interact with DynamoDB:

```python
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def create_item(user_id, item_data):
    """Create a new item in DynamoDB"""
    timestamp = datetime.utcnow().isoformat()
    
    item = {
        'PK': f'USER#{user_id}',
        'SK': f'ITEM#{timestamp}',
        'GSI1PK': 'ITEM',
        'GSI1SK': timestamp,
        'data': item_data,
        'createdAt': timestamp,
        'updatedAt': timestamp
    }
    
    table.put_item(Item=item)
    return item

def get_user_items(user_id):
    """Get all items for a user"""
    response = table.query(
        KeyConditionExpression='PK = :pk AND begins_with(SK, :sk)',
        ExpressionAttributeValues={
            ':pk': f'USER#{user_id}',
            ':sk': 'ITEM#'
        }
    )
    return response['Items']

def get_all_items():
    """Get all items using GSI"""
    response = table.query(
        IndexName='GSI1',
        KeyConditionExpression='GSI1PK = :pk',
        ExpressionAttributeValues={
            ':pk': 'ITEM'
        },
        ScanIndexForward=False  # Newest first
    )
    return response['Items']
```

### Step 7: Verify Table Creation

```bash
# List tables
aws dynamodb list-tables

# Describe table
aws dynamodb describe-table --table-name secure-serverless-table

# Test put item
aws dynamodb put-item \
    --table-name secure-serverless-table \
    --item '{"PK": {"S": "USER#test"}, "SK": {"S": "ITEM#001"}, "data": {"S": "test data"}}'

# Query items
aws dynamodb query \
    --table-name secure-serverless-table \
    --key-condition-expression "PK = :pk" \
    --expression-attribute-values '{":pk": {"S": "USER#test"}}'
```

![DynamoDB Items](/images/5-Workshop/5.4-Backend/5.4.2/dynamodb-items.png)

{{% notice tip %}}
Use single-table design patterns in DynamoDB for better performance and cost efficiency. Design your access patterns first, then create the table schema.
{{% /notice %}}

#### Images Required:
- `dynamodb-design.png` - Table schema design diagram
- `create-table.png` - DynamoDB create table console
- `gsi-config.png` - Global Secondary Index configuration
- `dynamodb-items.png` - Items in DynamoDB table
