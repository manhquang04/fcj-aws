﻿---
title: "Set up Lambda and API Gateway"
date: "2024-01-01"
weight: 1
chapter: false
pre: " <b> 5.4.1. </b> "
---

## Set up Lambda and API Gateway

In this section, you will create Lambda functions and configure API Gateway to expose them as REST APIs.

### Step 1: Create Lambda Execution Role

Navigate to **IAM Console** → **Roles** → **Create Role**

![Lambda Role](/images/5-Workshop/5.4-Backend/5.4.1/lambda-role.png)

Create a role with the following policies:
- `AWSLambdaBasicExecutionRole`
- `AmazonDynamoDBFullAccess`
- `SecretsManagerReadWrite`

### Step 2: Create Lambda Function

#### 2.1 Using Terraform

```hcl
# lambda/main.tf
resource "aws_lambda_function" "api_handler" {
  function_name = "secure-serverless-api"
  role          = aws_iam_role.lambda_exec.arn
  package_type  = "Image"
  image_uri     = "${var.ecr_repo_url}:latest"
  
  timeout     = 30
  memory_size = 256
  
  environment {
    variables = {
      TABLE_NAME      = var.dynamodb_table_name
      ENVIRONMENT     = var.environment
      SECRETS_ARN     = var.secrets_arn
    }
  }
  
  vpc_config {
    subnet_ids         = var.subnet_ids
    security_group_ids = var.security_group_ids
  }
  
  tracing_config {
    mode = "Active"
  }
}

resource "aws_iam_role" "lambda_exec" {
  name = "lambda-exec-role"
  
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "lambda.amazonaws.com"
      }
    }]
  })
}
```

#### 2.2 Using AWS Console

1. Navigate to **Lambda Console** → **Create function**
2. Select **Container image**
3. Configure:
   - **Function name**: `secure-serverless-api`
   - **Container image URI**: Your ECR image URI
   - **Execution role**: Role created in Step 1

![Create Lambda](/images/5-Workshop/5.4-Backend/5.4.1/create-lambda.png)

### Step 3: Create API Gateway

#### 3.1 Create REST API

```hcl
# api-gateway/main.tf
resource "aws_api_gateway_rest_api" "main" {
  name        = "secure-serverless-api"
  description = "Secure Serverless Application API"
  
  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_api_gateway_resource" "items" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_rest_api.main.root_resource_id
  path_part   = "items"
}

resource "aws_api_gateway_method" "get_items" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  resource_id   = aws_api_gateway_resource.items.id
  http_method   = "GET"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}

resource "aws_api_gateway_integration" "lambda" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  resource_id = aws_api_gateway_resource.items.id
  http_method = aws_api_gateway_method.get_items.http_method
  
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.api_handler.invoke_arn
}
```

#### 3.2 Configure CORS

```hcl
resource "aws_api_gateway_method" "options" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  resource_id   = aws_api_gateway_resource.items.id
  http_method   = "OPTIONS"
  authorization = "NONE"
}

resource "aws_api_gateway_integration" "options" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  resource_id = aws_api_gateway_resource.items.id
  http_method = aws_api_gateway_method.options.http_method
  type        = "MOCK"
  
  request_templates = {
    "application/json" = "{\"statusCode\": 200}"
  }
}

resource "aws_api_gateway_method_response" "options" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  resource_id = aws_api_gateway_resource.items.id
  http_method = aws_api_gateway_method.options.http_method
  status_code = "200"
  
  response_parameters = {
    "method.response.header.Access-Control-Allow-Headers" = true
    "method.response.header.Access-Control-Allow-Methods" = true
    "method.response.header.Access-Control-Allow-Origin"  = true
  }
}
```

![API Gateway Console](/images/5-Workshop/5.4-Backend/5.4.1/api-gateway-console.png)

### Step 4: Deploy API

```hcl
resource "aws_api_gateway_deployment" "main" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  
  depends_on = [
    aws_api_gateway_integration.lambda
  ]
  
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_stage" "prod" {
  deployment_id = aws_api_gateway_deployment.main.id
  rest_api_id   = aws_api_gateway_rest_api.main.id
  stage_name    = "prod"
  
  xray_tracing_enabled = true
  
  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_gw.arn
    format = jsonencode({
      requestId       = "$context.requestId"
      ip              = "$context.identity.sourceIp"
      requestTime     = "$context.requestTime"
      httpMethod      = "$context.httpMethod"
      resourcePath    = "$context.resourcePath"
      status          = "$context.status"
      responseLength  = "$context.responseLength"
    })
  }
}
```

### Step 5: Grant Lambda Permission

```hcl
resource "aws_lambda_permission" "api_gw" {
  statement_id  = "AllowExecutionFromAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.api_handler.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.main.execution_arn}/*/*"
}
```

### Step 6: Test the API

```bash
# Get the API endpoint
API_ENDPOINT=$(aws apigateway get-rest-apis --query "items[?name=='secure-serverless-api'].id" --output text)
API_URL="https://${API_ENDPOINT}.execute-api.ap-southeast-1.amazonaws.com/prod"

# Test the endpoint (without auth - should fail)
curl -X GET ${API_URL}/items

# Test with Cognito token (will set up in next section)
curl -X GET ${API_URL}/items \
  -H "Authorization: Bearer ${ID_TOKEN}"
```

![API Test](/images/5-Workshop/5.4-Backend/5.4.1/api-test.png)

#### Images Required:
- `lambda-role.png` - IAM role for Lambda
- `create-lambda.png` - Lambda function creation
- `api-gateway-console.png` - API Gateway resources
- `api-test.png` - API testing with curl
