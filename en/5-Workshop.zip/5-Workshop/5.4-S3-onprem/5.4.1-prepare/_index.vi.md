﻿---
title: "Thiết lập Lambda và API Gateway"
date: "2024-01-01"
weight: 1
chapter: false
pre: " <b> 5.4.1. </b> "
---

## Thiết lập Lambda và API Gateway

Trong phần này, bạn sẽ tạo Lambda functions và cấu hình API Gateway để expose chúng dưới dạng REST APIs.

### Bước 1: Tạo Lambda Execution Role

Điều hướng đến **IAM Console** → **Roles** → **Create Role**

![Lambda Role](/images/5-Workshop/5.4-Backend/5.4.1/lambda-role.png)

Tạo role với các policies sau:
- `AWSLambdaBasicExecutionRole`
- `AmazonDynamoDBFullAccess`
- `SecretsManagerReadWrite`

### Bước 2: Tạo Lambda Function

#### 2.1 Sử dụng Terraform

```hcl
# lambda/main.tf
resource "aws_lambda_function" "api_handler" {
  function_name = "secure-serverless-api"
  role          = aws_iam_role.lambda_exec.arn
  package_type  = "Image"
  image_uri     = "${var.ecr_repo_url}:latest"
  
  timeout     = 30
  memory_size = 256
  
  environment {
    variables = {
      TABLE_NAME      = var.dynamodb_table_name
      ENVIRONMENT     = var.environment
      SECRETS_ARN     = var.secrets_arn
    }
  }
  
  vpc_config {
    subnet_ids         = var.subnet_ids
    security_group_ids = var.security_group_ids
  }
  
  tracing_config {
    mode = "Active"
  }
}

resource "aws_iam_role" "lambda_exec" {
  name = "lambda-exec-role"
  
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "lambda.amazonaws.com"
      }
    }]
  })
}
```

#### 2.2 Sử dụng AWS Console

1. Điều hướng đến **Lambda Console** → **Create function**
2. Chọn **Container image**
3. Cấu hình:
   - **Function name**: `secure-serverless-api`
   - **Container image URI**: ECR image URI của bạn
   - **Execution role**: Role đã tạo ở Bước 1

![Create Lambda](/images/5-Workshop/5.4-Backend/5.4.1/create-lambda.png)

### Bước 3: Tạo API Gateway

#### 3.1 Tạo REST API

```hcl
# api-gateway/main.tf
resource "aws_api_gateway_rest_api" "main" {
  name        = "secure-serverless-api"
  description = "Secure Serverless Application API"
  
  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_api_gateway_resource" "items" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_rest_api.main.root_resource_id
  path_part   = "items"
}

resource "aws_api_gateway_method" "get_items" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  resource_id   = aws_api_gateway_resource.items.id
  http_method   = "GET"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}

resource "aws_api_gateway_integration" "lambda" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  resource_id = aws_api_gateway_resource.items.id
  http_method = aws_api_gateway_method.get_items.http_method
  
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.api_handler.invoke_arn
}
```

#### 3.2 Cấu hình CORS

```hcl
resource "aws_api_gateway_method" "options" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  resource_id   = aws_api_gateway_resource.items.id
  http_method   = "OPTIONS"
  authorization = "NONE"
}

resource "aws_api_gateway_integration" "options" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  resource_id = aws_api_gateway_resource.items.id
  http_method = aws_api_gateway_method.options.http_method
  type        = "MOCK"
  
  request_templates = {
    "application/json" = "{\"statusCode\": 200}"
  }
}

resource "aws_api_gateway_method_response" "options" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  resource_id = aws_api_gateway_resource.items.id
  http_method = aws_api_gateway_method.options.http_method
  status_code = "200"
  
  response_parameters = {
    "method.response.header.Access-Control-Allow-Headers" = true
    "method.response.header.Access-Control-Allow-Methods" = true
    "method.response.header.Access-Control-Allow-Origin"  = true
  }
}
```

![API Gateway Console](/images/5-Workshop/5.4-Backend/5.4.1/api-gateway-console.png)

### Bước 4: Deploy API

```hcl
resource "aws_api_gateway_deployment" "main" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  
  depends_on = [
    aws_api_gateway_integration.lambda
  ]
  
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_stage" "prod" {
  deployment_id = aws_api_gateway_deployment.main.id
  rest_api_id   = aws_api_gateway_rest_api.main.id
  stage_name    = "prod"
  
  xray_tracing_enabled = true
  
  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_gw.arn
    format = jsonencode({
      requestId       = "$context.requestId"
      ip              = "$context.identity.sourceIp"
      requestTime     = "$context.requestTime"
      httpMethod      = "$context.httpMethod"
      resourcePath    = "$context.resourcePath"
      status          = "$context.status"
      responseLength  = "$context.responseLength"
    })
  }
}
```

### Bước 5: Cấp quyền cho Lambda

```hcl
resource "aws_lambda_permission" "api_gw" {
  statement_id  = "AllowExecutionFromAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.api_handler.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.main.execution_arn}/*/*"
}
```

### Bước 6: Test API

```bash
# Lấy API endpoint
API_ENDPOINT=$(aws apigateway get-rest-apis --query "items[?name=='secure-serverless-api'].id" --output text)
API_URL="https://${API_ENDPOINT}.execute-api.ap-southeast-1.amazonaws.com/prod"

# Test endpoint (không có auth - sẽ fail)
curl -X GET ${API_URL}/items

# Test với Cognito token (sẽ thiết lập ở phần tiếp theo)
curl -X GET ${API_URL}/items \
  -H "Authorization: Bearer ${ID_TOKEN}"
```

![API Test](/images/5-Workshop/5.4-Backend/5.4.1/api-test.png)

#### Ảnh cần thiết:
- `lambda-role.png` - IAM role cho Lambda
- `create-lambda.png` - Tạo Lambda function
- `api-gateway-console.png` - API Gateway resources
- `api-test.png` - Test API với curl
